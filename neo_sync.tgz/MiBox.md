# 📺 Google TV Temel Kurulum Adımları

`Mi Box`, `Mi Stick`, `Fire Stick`, `Google TV`, `Android TV` vb. cihazların daha az yük altında çalışması için temiz kurulum adımları..

> [![Sonuc](.github/icons/MiBox/Sonuc.png)](#)

---

## 1. **Geliştirici seçenekleri**ni aktif edin.
> [![Gelistirici](.github/icons/MiBox/Gelistirici.jpg)](#)


## 2. **Animasyon ölçekleri**ni 0.5'e düşürün.
> [![Animasyon](.github/icons/MiBox/Animasyon.jpg)](#)


## 3. **USB Hata Ayıklaması**nı aktif edin.
> [![ADB](.github/icons/MiBox/ADB.jpg)](#)


## 4. **Hesap Ayarları**ndan fragman otomatik oynatmayı kapatın, yalnızca uygulama modunu açın.
> [![Uygulama](.github/icons/MiBox/Uygulama.jpg)](#)


## 5. Bilgisayarınıza _[ADB AppControl](https://adbappcontrol.com/en/#download)_ programını kurun ve TV'deki gereksiz uygulamaları kaldırın.
> [![AppControl](.github/icons/MiBox/AppControl.jpg)](#)


## 6. **PlayStore**'dan gerekli uygulamaları kurun;
> - _[Cx Dosya Gezgini](https://play.google.com/store/apps/details?id=com.cxinventor.file.explorer)_
> - _[Downloader by AFTVnews](https://play.google.com/store/apps/details?id=com.esaba.downloader)_
> - _[Button Mapper: Remap your keys](https://play.google.com/store/apps/details?id=flar2.homebutton)_

> [![PlayStore](.github/icons/MiBox/PlayStore.png)](#)


## 7. **Downloader** ile gerekli uygulamarı kurun
> - _[SmartTube](https://github.com/yuliskov/SmartTube)_ » `54794`
> - _[CloudStream](https://github.com/recloudstream/cloudstream)_ » `532423`

> [![Downloader](.github/icons/MiBox/Downloader.png)](#)


## 8. **CloudStream**'e _[NeO deposunu ekleyin](README.md#-kurulum)_
