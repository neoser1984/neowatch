version = 5

cloudstream {
    authors     = listOf("Cloudburst", "NeO")
    language    = "tr"
    description = "YouTube, izlediğiniz videolarla önerilerini iyileştirir. İlginizi çekebilecek içeriklerle dolu bir akış oluşturmak için video izlemeye başlayın."

    /**
     * Status int as the following:
     * 0: Down
     * 1: Ok
     * 2: Slow
     * 3: Beta only
    **/
    status  = 1
    tvTypes = listOf("Others")
    iconUrl = "https://www.google.com/s2/favicons?domain=youtube.com&sz=%size%"
}
