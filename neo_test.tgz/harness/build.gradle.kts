plugins {
    kotlin("jvm") version "2.3.0"
    application
}

val csSurum = (findProperty("csSurum") as String?) ?: "4.8.0"

dependencies {
    implementation("com.github.recloudstream.cloudstream:library-jvm:$csSurum")
    implementation("com.github.Blatzar:NiceHttp:0.4.18")
    implementation("org.jsoup:jsoup:1.22.1")
    implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")
    implementation("org.mozilla:rhino:1.8.1")
    implementation("org.json:json:20240303")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}

kotlin {
    jvmToolchain(17)
}

application {
    mainClass.set("TestKt")
}
