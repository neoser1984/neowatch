package android.util

object Log {
    @JvmStatic fun d(tag: String?, msg: String?): Int { println("    [D/$tag] ${msg?.take(400)}"); return 0 }
    @JvmStatic fun i(tag: String?, msg: String?): Int { println("    [I/$tag] ${msg?.take(400)}"); return 0 }
    @JvmStatic fun w(tag: String?, msg: String?): Int { println("    [W/$tag] ${msg?.take(400)}"); return 0 }
    @JvmStatic fun e(tag: String?, msg: String?): Int { println("    [E/$tag] ${msg?.take(400)}"); return 0 }
    @JvmStatic fun e(tag: String?, msg: String?, t: Throwable?): Int { println("    [E/$tag] ${msg?.take(400)} $t"); return 0 }
}
