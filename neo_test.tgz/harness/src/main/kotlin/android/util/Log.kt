package android.util

object Log {
    @JvmField var sessiz = false
    private fun yaz(s: String) { if (!sessiz) println(s) }
    @JvmStatic fun d(tag: String?, msg: String?): Int { yaz("    [D/$tag] ${msg?.take(400)}"); return 0 }
    @JvmStatic fun i(tag: String?, msg: String?): Int { yaz("    [I/$tag] ${msg?.take(400)}"); return 0 }
    @JvmStatic fun w(tag: String?, msg: String?): Int { yaz("    [W/$tag] ${msg?.take(400)}"); return 0 }
    @JvmStatic fun e(tag: String?, msg: String?): Int { yaz("    [E/$tag] ${msg?.take(400)}"); return 0 }
    @JvmStatic fun e(tag: String?, msg: String?, t: Throwable?): Int { yaz("    [E/$tag] ${msg?.take(400)} $t"); return 0 }
}
