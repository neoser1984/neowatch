package android.webkit

// Test ortamı için taslak: Android'de gerçek CookieManager kullanılır
class CookieManager {
    fun getCookie(url: String?): String? = null
    companion object {
        @JvmStatic fun getInstance(): CookieManager = CookieManager()
    }
}
