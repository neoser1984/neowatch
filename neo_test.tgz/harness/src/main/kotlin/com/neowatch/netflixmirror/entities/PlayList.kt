package com.neowatch.netflixmirror.entities

class PlayList : ArrayList<PlayListItem>()
