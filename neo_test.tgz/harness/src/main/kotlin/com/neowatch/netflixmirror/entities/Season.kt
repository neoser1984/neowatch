package com.neowatch.netflixmirror.entities

data class Season(
    val ep: String,
    val id: String,
    val s: String,
    val sele: String
)
