package com.neowatch.netflixmirror.entities

data class SearchResult(
    val id: String,
    val t: String
)
