package com.lagradost.cloudstream3

// Test ortamı için taslak: uygulamadaki CommonActivity.showToast
object CommonActivity {
    fun showToast(message: String?, duration: Int? = null) { println("TOAST » $message") }
}
