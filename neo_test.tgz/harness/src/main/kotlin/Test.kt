import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.jsoup.Jsoup

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

suspend fun dene(api: MainAPI, kategoriSayisi: Int = 4, arama: String? = null) {
    println("\n==================== ${api.name} (${api.mainUrl}) — kategori ${api.mainPage.size} ====================")
    var ilk: SearchResponse? = null
    for (k in api.mainPage.take(kategoriSayisi)) {
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("KAT ${k.name} -> ${l.size} hasNext=${r.getOrNull()?.hasNext} ${r.exceptionOrNull() ?: ""} | ${l.take(2).joinToString { "${it.name} ${it.url}" }}")
        if (ilk == null) ilk = l.firstOrNull { it.type != TvType.Movie } ?: l.firstOrNull()
    }
    if (arama != null) {
        val s = runCatching { api.search(arama) }
        println("ARAMA $arama -> ${s.getOrNull()?.size} ${s.exceptionOrNull() ?: ""} | ${s.getOrNull()?.take(3)?.joinToString { "${it.name} ${it.url}" }}")
    }
    val hedef = ilk ?: return
    val y = runCatching { withTimeout(120_000) { api.load(hedef.url) } }
    val yy = y.getOrNull()
    println("LOAD ${hedef.url} -> ${yy?.name} ${yy?.type} yıl=${yy?.year} poster=${yy?.posterUrl?.take(80)} ${y.exceptionOrNull() ?: ""}")
    val veri = when (yy) { is TvSeriesLoadResponse -> { println("   bölüm=${yy.episodes.size} ilk=${yy.episodes.firstOrNull()?.data}"); yy.episodes.firstOrNull()?.data }; is MovieLoadResponse -> yy.dataUrl; else -> null } ?: return
    val links = mutableListOf<ExtractorLink>(); val subs = mutableListOf<SubtitleFile>()
    val ok = runCatching { withTimeout(120_000) { api.loadLinks(veri, false, { subs.add(it) }, { links.add(it) }) } }
    println("   LINKS ok=${ok.getOrNull()} ${ok.exceptionOrNull() ?: ""} altyazı=${subs.size}")
    links.forEach { l -> val m = runCatching { app.get(l.url, headers = l.headers + mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} ${l.type} -> ${m?.code} ${m?.headers?.get("content-type")} | ${l.url.take(100)}") }
}

fun main(args: Array<String>) = runBlocking {
    println("=== DiziPal derin test ===")
    val bolum = "https://dizipal2142.com/bolum/the-new-stanford-prison-experiment-1-sezon-6-bolum"
    val dizi  = "https://dizipal2142.com/dizi/the-new-stanford-prison-experiment"
    for ((ad, h) in listOf("varsayilan" to emptyMap<String, String>(), "UA" to UA)) {
        for (u in listOf(bolum, dizi)) {
            val r = runCatching { app.get(u, headers = h, referer = "https://dizipal2142.com/", timeout = 25) }
            val d = r.getOrNull()?.document
            println("[$ad] $u -> ${r.getOrNull()?.code} ${r.exceptionOrNull() ?: ""} başlık=${d?.title()?.take(70)} btn=${d?.select("a.btn-watch-first")?.size} nav=${d?.select("a.ep-nav-all")?.size} h1=${d?.selectFirst("h1")?.className()} ep=${d?.select("a.detail-episode-item")?.size} cfg=${d?.selectFirst("#videoContainer")?.attr("data-cfg")?.length}")
        }
    }
    runCatching {
        val js = app.get("https://dizipal2142.com/public/assets/js/main.js", headers = UA, referer = bolum, timeout = 25).text
        println("main.js uzunluk=${js.length}")
        for (k in listOf("ajax-player-config", "ajax-token")) {
            var i = js.indexOf(k)
            var n = 0
            while (i >= 0 && n < 3) { println("---- $k @$i ----\n" + js.substring(maxOf(0, i - 1200), minOf(js.length, i + 1500))); i = js.indexOf(k, i + 1); n++ }
        }
    }.onFailure { println("main.js hata $it") }
    val api = DiziPal()
    for (u in listOf(dizi, bolum, "https://dizipal2142.com/film/moana-2026")) {
        val y = runCatching { withTimeout(120_000) { api.load(u) } }
        val yy = y.getOrNull()
        println("LOAD $u -> ${yy?.name} ${yy?.type} yıl=${yy?.year} ${y.exceptionOrNull() ?: ""}")
        val veri = when (yy) { is TvSeriesLoadResponse -> { println("   bölüm=${yy.episodes.size} son=${yy.episodes.lastOrNull()?.data}"); yy.episodes.lastOrNull()?.data }; is MovieLoadResponse -> yy.dataUrl; else -> null } ?: continue
        val links = mutableListOf<ExtractorLink>(); val subs = mutableListOf<SubtitleFile>()
        val ok = runCatching { withTimeout(120_000) { api.loadLinks(veri, false, { subs.add(it) }, { links.add(it) }) } }
        println("   LINKS ok=${ok.getOrNull()} ${ok.exceptionOrNull() ?: ""} altyazı=${subs.size}")
        links.forEach { l -> val m = runCatching { app.get(l.url, headers = l.headers + mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} ${l.type} -> ${m?.code} ${m?.headers?.get("content-type")} | ${l.url.take(100)}") }
    }
    println("\n=== BİTTİ ===")
}
