import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.runBlocking
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")
val ANA = "https://superfilmizle.org"

fun tek(s: String) = s.replace(Regex("\\s+"), " ")

suspend fun getir(url: String, ref: String? = null): Document? {
    val r = runCatching { app.get(url, headers = UA, referer = ref, timeout = 30) }
    val y = r.getOrNull()
    if (y == null) { println("GET $url -> HATA ${r.exceptionOrNull()}"); return null }
    println("GET $url -> ${y.code} son=${y.url} | başlık=${Jsoup.parse(y.text).title().take(90)} | uzunluk=${y.text.length}")
    return Jsoup.parse(y.text, y.url)
}

fun yollar(doc: Document) {
    val hrefs = doc.select("a[href]").map { it.attr("abs:href") }.filter { it.startsWith(ANA) }.distinct()
    val grup = hrefs.groupBy { it.removePrefix(ANA).trim('/').split("/").firstOrNull() ?: "" }
    grup.entries.sortedByDescending { it.value.size }.take(15).forEach { (k, v) -> println("   /$k (${v.size}): ${v.take(4).joinToString(" ")}") }
}

fun kartlar(doc: Document, desen: String): List<Element> {
    val linkler = doc.select("a[href*=$desen]").filter { it.selectFirst("img") != null || it.parent()?.selectFirst("img") != null }
    println("   '$desen' içeren görselli bağlantı sayısı: ${linkler.size}")
    linkler.firstOrNull()?.let { a ->
        var e: Element = a
        repeat(3) { e.parent()?.let { p -> if (p.select("a[href*=$desen]").size <= 2) e = p } }
        println("   İLK KART (üst öğe ${e.tagName()}.${e.className()}): " + tek(e.outerHtml()).take(2200))
    }
    return linkler
}

fun bagliam(html: String, kelimeler: List<String>, n: Int = 3) {
    for (k in kelimeler) {
        var i = html.indexOf(k); var say = 0
        while (i >= 0 && say < n) {
            println("   «$k» … " + tek(html.substring(maxOf(0, i - 250), minOf(html.length, i + 450))))
            i = html.indexOf(k, i + k.length); say++
        }
    }
}


val HARIC = setOf("category", "platform", "dizi-kategori", "locale", "film-izle", "dizi-izle", "animes", "kesfet", "takvim", "forum", "uye-girisi", "trend", "koleksiyonlar", "ara", "page", "")
fun icerikMi(u: String): Boolean { if (!u.startsWith(ANA)) return false; val ilk = u.removePrefix(ANA).trim('/').split("/").first().substringBefore("?"); return ilk !in HARIC }

fun kartGoster(doc: Document, etiket: String) {
    val a = doc.select("a[href]").filter { icerikMi(it.attr("abs:href")) && (it.selectFirst("img") != null) }
    println("   [$etiket] içerik kartı: ${a.size} | ilk 6: " + a.take(6).joinToString(" ") { it.attr("abs:href") })
    a.firstOrNull()?.let { x ->
        var e: Element = x
        repeat(4) { e.parent()?.let { p -> if (p.select("a[href]").count { icerikMi(it.attr("abs:href")) } <= 2) e = p } }
        println("   [$etiket] KART HTML (${e.tagName()}): " + tek(e.outerHtml()).take(2500))
    }
}

suspend fun sayfaIncele(url: String, kelimeler: List<String>) {
    val r = runCatching { app.get(url, headers = UA, timeout = 30) }.getOrNull() ?: run { println("HATA $url"); return }
    val d = Jsoup.parse(r.text, r.url)
    println("\n##### $url -> ${r.code} | başlık=${d.title()} | h1=${d.select("h1").text()} | uzunluk=${r.text.length}")
    println("   og:image=${d.selectFirst("meta[property=og:image]")?.attr("content")} | og:type=${d.selectFirst("meta[property=og:type]")?.attr("content")}")
    println("   description=${d.selectFirst("meta[name=description]")?.attr("content")?.take(250)}")
    println("   iframe: " + d.select("iframe").map { it.attr("src") + " | data-src=" + it.attr("data-src") })
    println("   ld+json: " + d.select("script[type=application/ld+json]").map { tek(it.data()).take(1200) })
    val main = d.selectFirst("main") ?: d.body()
    println("   MAIN METİN: " + tek(main.text()).take(1500))
    bagliam(r.text, kelimeler, 3)
    val linkler = d.select("a[href]").map { it.attr("abs:href") }.filter { it.contains("/bolum/") || it.contains("sezon") }.distinct()
    println("   bölüm/sezon bağlantıları (${linkler.size}): " + linkler.take(12).joinToString(" "))
    val scriptler = d.select("script[src]").map { it.attr("abs:src") }
    println("   script src: " + scriptler.take(20))
    val butonlar = d.select("[data-id], [data-src], [data-url], [data-embed], [data-video], [data-player], [data-source], [data-link], [x-data]").take(15).map { tek(it.outerHtml()).take(400) }
    println("   data-* öğeleri: " + butonlar.joinToString("\n      "))
}


suspend fun oynatici(url: String) {
    val r = app.get(url, headers = UA, timeout = 30)
    val d = Jsoup.parse(r.text, r.url)
    println("\n##### OYNATICI $url -> ${r.code}")
    val kutu = d.selectFirst("[data-player-shell]")
    println("   KUTU HTML: " + (kutu?.outerHtml()?.let { tek(it).replace(Regex("<svg[\\s\\S]*?</svg>"), "<svg/>") }?.take(7000) ?: "yok"))
    println("   template: " + d.select("template").map { tek(it.outerHtml()).take(800) })
    val html = r.text
    for (k in listOf("pilavyerplay", "data-embed", "data-src", "data-source", "data-url", "data-iframe", "playerSources", "sources", "embed_url", "embedUrl", "/izle/", "kaynak", "source-", "data-tab")) {
        var i = html.indexOf(k); var n = 0
        while (i >= 0 && n < 4) { println("   «$k» … " + tek(html.substring(maxOf(0, i - 200), minOf(html.length, i + 400))).replace(Regex("<svg[\\s\\S]*?</svg>"), "<svg/>")); i = html.indexOf(k, i + k.length); n++ }
    }
    // script blokları içinde oynatıcıyla ilgili olanlar
    d.select("script:not([src])").map { it.data() }.filter { it.contains("player", true) && (it.contains("iframe") || it.contains("src")) }.forEach { println("   SCRIPT: " + tek(it).take(3000)) }
}

fun main(args: Array<String>) = runBlocking {
    println("=== superfilmizle.org oynatıcı ===")
    oynatici("$ANA/wonder-woman/")
    getir("$ANA/wonder-woman/izle/")?.let { println("   izle sayfası iframe: " + it.select("iframe").map { f -> f.attr("src") }) ; println("   izle metin: " + tek(it.body().text()).take(400)) }
    oynatici("$ANA/bolum/reacher-1-sezon-1-bolum/")
    oynatici("$ANA/anime/cyberpunk-edgerunners/sezon-1/bolum-1/")
    val core = runCatching { app.get("https://play2.pilavyerplay.top/assets/js/core.js", headers = UA, referer = "$ANA/", timeout = 30).text }.getOrNull()
    println("\n##### core.js uzunluk=${core?.length}: " + core?.take(4000)?.let { tek(it) })
    // dizi bölüm kartı
    val dd = Jsoup.parse(app.get("$ANA/dizi/reacher/?sezon=2", headers = UA, timeout = 30).text, "$ANA/")
    val kart = dd.selectFirst("section#bolumler a[href*=/bolum/]")
    println("\n##### BÖLÜM KARTI (sezon=2): " + (kart?.outerHtml()?.let { tek(it).replace(Regex("<svg[\\s\\S]*?</svg>"), "<svg/>") }?.take(2000) ?: "yok"))
    println("   sezon2 bölümleri: " + dd.select("section#bolumler a[href*=/bolum/]").map { it.attr("abs:href") }.distinct().take(10))
    println("\n=== BİTTİ ===")
}
