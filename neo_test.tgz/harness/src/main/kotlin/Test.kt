import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.jsoup.Jsoup

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

val EKLENTILER = listOf("AnimeciX", "BelgeselX", "CanliTV", "CizgiMax", "DiziBal", "DiziBox", "DiziKorea", "DiziMom", "DiziPal", "DiziPalGuncel", "DiziPalOrjinal", "DiziYou", "Dizilla", "FilmMakinesi", "FilmModu", "FullHDFilm", "FullHDFilmizlesene", "HDFilmCehennemi", "InatBox", "JetFilmizle", "KoreanTurk", "KultFilmler", "NetflixMirror", "RareFilmm", "RecTV", "SelcukFlix", "SetFilmIzle", "SezonlukDizi", "SinemaCX", "SuperFilmGeldi", "TurkAnime", "UgurFilm", "WebDramaTurkey", "WebteIzle", "YouTube")

// Kodu test düzeneğinde derlenmeyenler ve PR #4'teki aday adresler: yalnızca ham kontrol
val HAM = listOf(
    "https://watch2movies.net",
    "https://dizipal2145.com", "https://dizipalorjinal18.com", "https://superfilmizle.click"
)

fun hata(t: Throwable?) = t?.let { "HATA ${it.javaClass.simpleName}: ${it.message?.take(90)}" } ?: ""

suspend fun hamKontrol(u: String): String {
    val r1 = runCatching { app.get(u, headers = UA, allowRedirects = false, timeout = 20) }
    val c1 = r1.getOrNull() ?: return "ham=YOK ${hata(r1.exceptionOrNull())}"
    val sb = StringBuilder("ham=${c1.code} loc=${c1.headers["location"] ?: "-"}")
    var metin = c1.text
    if (c1.code in 300..399) {
        val r2 = runCatching { app.get(u, headers = UA, timeout = 25) }
        val c2 = r2.getOrNull()
        sb.append(" | son=${c2?.url} ${c2?.code} ${hata(r2.exceptionOrNull())}")
        metin = c2?.text ?: ""
    }
    val d = Jsoup.parse(metin)
    sb.append(" | başlık='${d.title().take(60)}' uzunluk=${metin.length} canonical=${d.selectFirst("link[rel=canonical]")?.attr("href") ?: "-"}")
    return sb.toString()
}

suspend fun eklentiTest(ad: String): String {
    val sb = StringBuilder()
    val api = runCatching { Class.forName("com.neowatch.${ad.lowercase()}.$ad").getDeclaredConstructor().newInstance() as MainAPI }
        .getOrElse { return "### $ad: OLUŞTURULAMADI ${hata(it)}" }
    sb.appendLine("### $ad (${api.mainUrl}) kategori=${api.mainPage.size}")
    if (api.mainUrl.startsWith("http")) sb.appendLine("  " + hamKontrol(api.mainUrl))
    var ilk: SearchResponse? = null
    for (k in api.mainPage.take(2)) {
        val r = runCatching { withTimeout(60_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        sb.appendLine("  KAT ${k.name} -> ${l.size} ${hata(r.exceptionOrNull())} | ${l.take(2).joinToString { it.name.take(40) }}")
        if (ilk == null) ilk = l.firstOrNull { it.type != TvType.Live } ?: l.firstOrNull()
    }
    val hedef = ilk ?: return sb.toString()
    val y = runCatching { withTimeout(60_000) { api.load(hedef.url) } }
    val yy = y.getOrNull()
    val veri = when (yy) {
        is TvSeriesLoadResponse -> yy.episodes.firstOrNull()?.data
        is AnimeLoadResponse    -> yy.episodes.values.flatten().firstOrNull()?.data
        is MovieLoadResponse    -> yy.dataUrl
        is LiveStreamLoadResponse -> yy.dataUrl
        else -> null
    }
    val bolum = when (yy) { is TvSeriesLoadResponse -> yy.episodes.size; is AnimeLoadResponse -> yy.episodes.values.sumOf { it.size }; else -> -1 }
    sb.appendLine("  LOAD ${hedef.name.take(40)} -> ${yy?.name?.take(40)} ${yy?.type} bölüm=$bolum ${hata(y.exceptionOrNull())}")
    if (veri != null) {
        val links = mutableListOf<ExtractorLink>()
        val ok = runCatching { withTimeout(70_000) { api.loadLinks(veri, false, {}, { links.add(it) }) } }
        sb.appendLine("  LINKS ok=${ok.getOrNull()} adet=${links.size} ${hata(ok.exceptionOrNull())} | ${links.take(3).joinToString { it.name.take(25) + " " + it.url.substringAfter("://").substringBefore("/") }}")
    }
    return sb.toString()
}

fun main(args: Array<String>) = runBlocking {
    android.util.Log.sessiz = true
    println("=== Tüm eklentiler kontrolü ===")
    val sem = Semaphore(6)
    val sonuc = EKLENTILER.map { ad ->
        async(Dispatchers.IO) {
            sem.withPermit { runCatching { withTimeout(240_000) { eklentiTest(ad) } }.getOrElse { "### $ad: ZAMAN AŞIMI/HATA ${hata(it)}" } }
        }
    }.awaitAll()
    sonuc.forEach { println(it) }
    for (u in HAM) println("### HAM $u\n  " + hamKontrol(u))
    println("\n=== BİTTİ ===")
}
