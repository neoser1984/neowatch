import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout

fun main(args: Array<String>) = runBlocking {
    val api = SuperFilmGeldi()
    println("=== SuperFilmGeldi son test — kategori: ${api.mainPage.size} ===")
    for ((i, k) in api.mainPage.withIndex()) {
        val r = runCatching { withTimeout(60_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        var s2 = ""
        if (k.data.contains("?") || i % 6 == 0) {
            val r2 = runCatching { withTimeout(60_000) { api.getMainPage(2, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
            val l2 = r2.getOrNull()?.items?.flatMap { it.list }.orEmpty()
            s2 = " | s2=${l2.size} hasNext=${r2.getOrNull()?.hasNext} farklı=${l2.firstOrNull()?.url != l.firstOrNull()?.url}"
        }
        println("KAT ${k.name} -> ${l.size} hasNext=${r.getOrNull()?.hasNext} ${r.exceptionOrNull()?.let { "HATA $it" } ?: ""} | ${l.take(2).joinToString { "${it.name} [${it.type}]" }}$s2")
    }
    for (u in listOf("https://superfilmizle.org/matrix/", "https://superfilmizle.org/dizi/the-mentalist/")) {
        val y = runCatching { withTimeout(120_000) { api.load(u) } }.getOrNull()
        val veri = when (y) { is MovieLoadResponse -> y.dataUrl; is TvSeriesLoadResponse -> { println("   ${y.name}: ${y.episodes.size} bölüm, sezonlar ${y.episodes.map { it.season }.distinct()}"); y.episodes.lastOrNull()?.data }; else -> null }
        println("LOAD $u -> ${y?.name} ${y?.type} veri=$veri")
        if (veri == null) continue
        val linkler = mutableListOf<ExtractorLink>(); val alt = mutableListOf<SubtitleFile>()
        runCatching { withTimeout(90_000) { api.loadLinks(veri, false, { alt.add(it) }, { linkler.add(it) }) } }.onFailure { println("   HATA $it") }
        println("   altyazı=${alt.map { it.lang }}")
        linkler.forEach { l -> val m = runCatching { app.get(l.url, headers = l.headers + mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} -> ${m?.code} ${m?.headers?.get("content-type")}") }
    }
    println("\n=== BİTTİ ===")
}
