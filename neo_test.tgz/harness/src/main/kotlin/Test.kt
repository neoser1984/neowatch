import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody

data class Hedef(val api: MainAPI, val arama: String?, val dogrudan: List<String>)

fun main(args: Array<String>) = runBlocking {
    val hepsi = listOf<Hedef>()

    println("=== InatBox ham yoklama ===")
    for (u in listOf(
        "https://dizilabmedia.click/CDN/001/002/dizilab/v2/ct.php",
        "https://dizilabmedia.click/CDN/001/002/dizilab/v2/cf.php",
        "https://diziboxen.help/CDN/001/002/dizibox/v2/tv/ulusal.php",
        "https://sprboxs.bar/CDN/001/SPR/v2/spor_v3.php",
        "https://dizilabmedia.click/CDN/001/002/dizilab/v2/tv/ulusal.php"
    )) {
        for (get in listOf(false, true)) runCatching { inatHam(u, get) }.onFailure { println("!!! $u $it") }
    }
    println("=== InatBox eklenti ===")
    runCatching { kategoriTest(InatBox(), listOf("Ulusal", "Spor"), canlida = "Ulusal") }.onFailure { println("!!! InatBox ek hata: $it") }

    val secim = args.toSet() - "ALL"
    for (h in hepsi) {
        if (secim.isNotEmpty() && h.api.name !in secim) continue
        runCatching { testEt(h) }.onFailure { println("!!! ${h.api.name} genel hata: $it") }
    }
    println("\n=== BİTTİ ===")
}

suspend fun ham(url: String) {
    val r = runCatching { app.get(url, timeout = 30) }
    val y = r.getOrNull()
    val baslik = y?.text?.let { Regex("""<title>([^<]*)</title>""").find(it)?.groupValues?.get(1) }
    println("HAM GET $url -> ${y?.code} son=${y?.url} | başlık=${baslik?.take(80)} | uzunluk=${y?.text?.length} ${r.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
    if (y != null && y.code != 200) {
        println("   gövde: " + y.text.replace(Regex("<script[\\s\\S]*?</script>|<style[\\s\\S]*?</style>"), "").replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").take(500))
        println("   başlıklar: server=${y.headers["server"]} cf-mitigated=${y.headers["cf-mitigated"]} set-cookie=${y.headers.values("set-cookie").map { it.substringBefore("=") }}")
    }
}

suspend fun testEt(h: Hedef) {
    val api = h.api
    println("\n==================== ${api.name} (${api.mainUrl}) ====================")
    ham(api.mainUrl)

    var ilk: SearchResponse? = null
    val istek = api.mainPage.firstOrNull()
    if (istek != null) {
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(istek.name, istek.data, istek.horizontalImages)) } }
        val liste = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("ANA SAYFA [${istek.name}] -> ${liste.size} öğe ${r.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        liste.take(3).forEach { println("   - ${it.name} | ${it.url} | ${it.posterUrl}") }
        ilk = liste.firstOrNull()
    }

    if (h.arama != null) {
        val s = runCatching { withTimeout(60_000) { api.search(h.arama) } }
        println("ARAMA '${h.arama}' -> ${s.getOrNull()?.size} ${s.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        s.getOrNull()?.take(3)?.forEach { println("   - ${it.name} | ${it.url}") }
    }

    val veriler = mutableListOf<String>()
    if (ilk != null) {
        val y = runCatching { withTimeout(120_000) { api.load(ilk.url) } }
        val lr = y.getOrNull()
        if (lr == null) {
            println("LOAD ${ilk.url} -> null ${y.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        } else {
            when (lr) {
                is TvSeriesLoadResponse -> {
                    println("LOAD DİZİ '${lr.name}' bölüm=${lr.episodes.size} yıl=${lr.year} poster=${lr.posterUrl} konu=${lr.plot?.take(60)}")
                    lr.episodes.take(2).forEach { println("   ep S${it.season}E${it.episode} ${it.name} | ${it.data}") }
                    lr.episodes.firstOrNull()?.data?.let { veriler.add(it) }
                }
                is MovieLoadResponse -> {
                    println("LOAD FİLM '${lr.name}' yıl=${lr.year} poster=${lr.posterUrl} konu=${lr.plot?.take(60)}")
                    veriler.add(lr.dataUrl)
                }
                else -> println("LOAD ${lr::class.simpleName} '${lr.name}'")
            }
        }
    }
    veriler.addAll(h.dogrudan)

    for (veri in veriler.distinct()) {
        println("-- LOADLINKS $veri")
        val linkler = mutableListOf<ExtractorLink>()
        val r = runCatching {
            withTimeout(150_000) {
                api.loadLinks(veri, false, { println("   ALTYAZI ${it.lang} | ${it.url}") }, { linkler.add(it) })
            }
        }
        println("   dönüş=${r.getOrNull()} link=${linkler.size} ${r.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        for (l in linkler) {
            println("   LINK ${l.source} | ${l.name} | ${l.type} | ${l.url.take(160)} | ref=${l.referer} | h=${l.headers}")
            val basliklar = l.headers.toMutableMap()
            if (l.type != ExtractorLinkType.M3U8) basliklar["Range"] = "bytes=0-2047"
            val t = runCatching { app.get(l.url, referer = l.referer.ifBlank { null }, headers = basliklar, timeout = 30) }
            val yanit = t.getOrNull()
            val ozet = if (l.type == ExtractorLinkType.M3U8) yanit?.text?.take(150)?.replace("\n", " ⏎ ") else "${yanit?.headers?.get("Content-Type")} ${yanit?.headers?.get("Content-Length")}"
            println("      erişim -> ${yanit?.code} $ozet ${t.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        }
    }
}


suspend fun kategoriTest(api: MainAPI, adlar: List<String>, dizide: String? = null, filmde: String? = null, canlida: String? = null) {
    for (ad in adlar) {
        val istek = api.mainPage.firstOrNull { it.name == ad } ?: run { println("KATEGORİ YOK $ad"); continue }
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(istek.name, istek.data, istek.horizontalImages)) } }
        val liste = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("KATEGORİ [$ad] -> ${liste.size} öğe ${r.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        liste.take(2).forEach { println("   - ${it.name} | ${it::class.simpleName} | ${it.url.take(120)}") }
        if (ad == dizide || ad == filmde || ad == canlida) {
            val ilk = liste.firstOrNull() ?: continue
            val y = runCatching { withTimeout(120_000) { api.load(ilk.url) } }
            val lr = y.getOrNull()
            val veri = when (lr) {
                is TvSeriesLoadResponse -> { println("   LOAD DİZİ '${lr.name}' bölüm=${lr.episodes.size}"); lr.episodes.firstOrNull()?.data }
                is AnimeLoadResponse -> { val e = lr.episodes.values.flatten(); println("   LOAD ANİME/DİZİ '${lr.name}' bölüm=${e.size} sezonlar=${lr.episodes.keys}"); e.firstOrNull()?.data }
                is MovieLoadResponse -> { println("   LOAD FİLM '${lr.name}'"); lr.dataUrl }
                is LiveStreamLoadResponse -> { println("   LOAD CANLI '${lr.name}'"); lr.dataUrl }
                null -> { println("   LOAD null ${y.exceptionOrNull()?.let { "HATA $it" } ?: ""}"); null }
                else -> { println("   LOAD ${lr::class.simpleName}"); null }
            } ?: continue
            println("   -- LOADLINKS ${veri.take(150)}")
            val linkler = mutableListOf<ExtractorLink>()
            val lr2 = runCatching { withTimeout(150_000) { api.loadLinks(veri, false, { println("   ALTYAZI ${it.lang}") }, { linkler.add(it) }) } }
            println("   dönüş=${lr2.getOrNull()} link=${linkler.size} ${lr2.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
            for (l in linkler.take(3)) {
                println("   LINK ${l.source} | ${l.name} | ${l.type} | ${l.url.substringBefore("?").take(120)} | ref=${l.referer} | h=${l.headers.keys}")
                val t = runCatching { app.get(l.url, referer = l.referer.ifBlank { null }, headers = l.headers + (if (l.type != ExtractorLinkType.M3U8) mapOf("Range" to "bytes=0-2047") else emptyMap()), timeout = 30) }
                val yanit = t.getOrNull()
                val ozet = if (l.type == ExtractorLinkType.M3U8) yanit?.text?.take(80)?.replace("\n", " ⏎ ") else "${yanit?.headers?.get("Content-Type")}"
                println("      erişim -> ${yanit?.code} $ozet ${t.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
            }
        }
    }
}


suspend fun inatHam(url: String, get: Boolean) {
    val hex = { b: ByteArray -> b.joinToString("") { "%02x".format(it) } }
    val rk = (1..16).map { "abcdefghijklmnopqrstuvwxyz0123456789"[java.util.Random().nextInt(36)] }.joinToString("")
    val govde = if (get) "" else "1=$rk&0=$rk"
    val yol = java.net.URI(url).rawPath
    val zaman = (System.currentTimeMillis() / 1000).toString()
    val nonce = hex(ByteArray(16).also { java.security.SecureRandom().nextBytes(it) })
    val bh = hex(java.security.MessageDigest.getInstance("SHA-256").digest(govde.toByteArray()))
    val mac = javax.crypto.Mac.getInstance("HmacSHA256"); mac.init(javax.crypto.spec.SecretKeySpec("x7kkk0qmqz63kj68tla5i7u26192v7zqnnddhjgm".toByteArray(), "HmacSHA256"))
    val sg = hex(mac.doFinal("${if (get) "GET" else "POST"}\n$yol\n$zaman\n$nonce\n$bh".toByteArray()))
    val h = mapOf("User-Agent" to "speedrestapi", "Referer" to "https://speedrestapi.com/", "X-Requested-With" to "com.bp.box", "Cache-Control" to "no-cache", "X-Ts" to zaman, "X-Nc" to nonce, "X-Sg" to sg)
    val y = if (get) app.get(url, headers = h) else app.post(url, headers = h, requestBody = govde.toRequestBody("application/x-www-form-urlencoded; charset=UTF-8".toMediaType()))
    val govdeMetin = y.text.replace(Regex("<script[\\s\\S]*?</script>|<style[\\s\\S]*?</style>"), "").replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").take(220)
    println("HAM ${if (get) "GET " else "POST"} $url -> ${y.code} server=${y.headers["server"]} x-st=${y.headers["x-st"]} cf-ray=${y.headers["cf-ray"]?.takeLast(3)} len=${y.text.length} | $govdeMetin")
    if (y.isSuccessful) println("   çözüm: " + (InatIstek.coz(y.text, listOf(rk, InatIstek.VARSAYILAN_ANAHTAR))?.take(300) ?: "ÇÖZÜLEMEDİ"))
}
