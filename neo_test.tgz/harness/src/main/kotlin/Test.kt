import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.jsoup.Jsoup

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

suspend fun dene(api: MainAPI, kategoriSayisi: Int = 4, arama: String? = null) {
    println("\n==================== ${api.name} (${api.mainUrl}) — kategori ${api.mainPage.size} ====================")
    var ilk: SearchResponse? = null
    for (k in api.mainPage.take(kategoriSayisi)) {
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("KAT ${k.name} -> ${l.size} hasNext=${r.getOrNull()?.hasNext} ${r.exceptionOrNull() ?: ""} | ${l.take(2).joinToString { "${it.name} ${it.url}" }}")
        if (ilk == null) ilk = l.firstOrNull { it.type != TvType.Movie } ?: l.firstOrNull()
    }
    if (arama != null) {
        val s = runCatching { api.search(arama) }
        println("ARAMA $arama -> ${s.getOrNull()?.size} ${s.exceptionOrNull() ?: ""} | ${s.getOrNull()?.take(3)?.joinToString { "${it.name} ${it.url}" }}")
    }
    val hedef = ilk ?: return
    val y = runCatching { withTimeout(120_000) { api.load(hedef.url) } }
    val yy = y.getOrNull()
    println("LOAD ${hedef.url} -> ${yy?.name} ${yy?.type} yıl=${yy?.year} poster=${yy?.posterUrl?.take(80)} ${y.exceptionOrNull() ?: ""}")
    val veri = when (yy) { is TvSeriesLoadResponse -> { println("   bölüm=${yy.episodes.size} ilk=${yy.episodes.firstOrNull()?.data}"); yy.episodes.firstOrNull()?.data }; is MovieLoadResponse -> yy.dataUrl; else -> null } ?: return
    val links = mutableListOf<ExtractorLink>(); val subs = mutableListOf<SubtitleFile>()
    val ok = runCatching { withTimeout(120_000) { api.loadLinks(veri, false, { subs.add(it) }, { links.add(it) }) } }
    println("   LINKS ok=${ok.getOrNull()} ${ok.exceptionOrNull() ?: ""} altyazı=${subs.size}")
    links.forEach { l -> val m = runCatching { app.get(l.url, headers = l.headers + mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} ${l.type} -> ${m?.code} ${m?.headers?.get("content-type")} | ${l.url.take(100)}") }
}

fun main(args: Array<String>) = runBlocking {
    println("=== DiziPal doğrulama sayfası ===")
    val bolum = "https://dizipal2142.com/bolum/the-new-stanford-prison-experiment-1-sezon-6-bolum"
    val r = app.get(bolum, headers = UA, referer = "https://dizipal2142.com/dizi/the-new-stanford-prison-experiment", timeout = 25)
    println("kod=${r.code} url=${r.url}")
    r.headers.forEach { (k, v) -> println("H $k: ${v.take(200)}") }
    println("COOKIES ${r.cookies}")
    println("----- HTML (${r.text.length}) -----")
    println(r.text.take(15000))
    println("----- HTML SONU -----")
    // script kaynakları
    Jsoup.parse(r.text, bolum).select("script[src]").forEach { sc ->
        val u = sc.attr("abs:src")
        val t = runCatching { app.get(u, headers = UA, referer = bolum, timeout = 20).text }.getOrNull() ?: ""
        println("----- JS $u (${t.length}) -----")
        println(t.take(6000))
    }
    // ana sayfanın verdiği çerezlerle tekrar
    val ana = app.get("https://dizipal2142.com/", headers = UA, timeout = 25)
    println("ANA cookies=${ana.cookies.keys}")
    val dizi = app.get("https://dizipal2142.com/dizi/the-new-stanford-prison-experiment", headers = UA, cookies = ana.cookies, referer = "https://dizipal2142.com/", timeout = 25)
    println("DIZI cookies=${dizi.cookies.keys}")
    val c2 = ana.cookies + dizi.cookies
    val r2 = app.get(bolum, headers = UA, cookies = c2, referer = "https://dizipal2142.com/dizi/the-new-stanford-prison-experiment", timeout = 25)
    println("CEREZLI bolum -> ${r2.code} başlık=${r2.document.title()} cfg=${r2.document.selectFirst("#videoContainer")?.attr("data-cfg")?.length}")
    println("\n=== BİTTİ ===")
}
