import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.jsoup.Jsoup

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

suspend fun dene(api: MainAPI, kategoriSayisi: Int = 4, arama: String? = null) {
    println("\n==================== ${api.name} (${api.mainUrl}) — kategori ${api.mainPage.size} ====================")
    var ilk: SearchResponse? = null
    for (k in api.mainPage.take(kategoriSayisi)) {
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("KAT ${k.name} -> ${l.size} hasNext=${r.getOrNull()?.hasNext} ${r.exceptionOrNull() ?: ""} | ${l.take(2).joinToString { "${it.name} ${it.url}" }}")
        if (ilk == null) ilk = l.firstOrNull { it.type != TvType.Movie } ?: l.firstOrNull()
    }
    if (arama != null) {
        val s = runCatching { api.search(arama) }
        println("ARAMA $arama -> ${s.getOrNull()?.size} ${s.exceptionOrNull() ?: ""} | ${s.getOrNull()?.take(3)?.joinToString { "${it.name} ${it.url}" }}")
    }
    val hedef = ilk ?: return
    val y = runCatching { withTimeout(120_000) { api.load(hedef.url) } }
    val yy = y.getOrNull()
    println("LOAD ${hedef.url} -> ${yy?.name} ${yy?.type} yıl=${yy?.year} poster=${yy?.posterUrl?.take(80)} ${y.exceptionOrNull() ?: ""}")
    val veri = when (yy) { is TvSeriesLoadResponse -> { println("   bölüm=${yy.episodes.size} ilk=${yy.episodes.firstOrNull()?.data}"); yy.episodes.firstOrNull()?.data }; is MovieLoadResponse -> yy.dataUrl; else -> null } ?: return
    val links = mutableListOf<ExtractorLink>(); val subs = mutableListOf<SubtitleFile>()
    val ok = runCatching { withTimeout(120_000) { api.loadLinks(veri, false, { subs.add(it) }, { links.add(it) }) } }
    println("   LINKS ok=${ok.getOrNull()} ${ok.exceptionOrNull() ?: ""} altyazı=${subs.size}")
    links.forEach { l -> val m = runCatching { app.get(l.url, headers = l.headers + mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} ${l.type} -> ${m?.code} ${m?.headers?.get("content-type")} | ${l.url.take(100)}") }
}

fun main(args: Array<String>) = runBlocking {
    println("=== DiziPal doğrulama betiği ===")
    val bolum = "https://dizipal2142.com/bolum/the-new-stanford-prison-experiment-1-sezon-6-bolum"
    val ana = app.get("https://dizipal2142.com/", headers = UA, timeout = 25)
    println("ANA cookies=${ana.cookies.keys}")
    val r = app.get(bolum, headers = UA, cookies = ana.cookies, referer = "https://dizipal2142.com/", timeout = 25)
    val cerez = ana.cookies + r.cookies
    val d = r.document
    val bc = d.selectFirst("meta[name=_bc]")?.attr("content") ?: ""
    println("kod=${r.code} başlık=${d.title()} bn=${d.selectFirst("meta[name=_bn]")?.attr("content")} bk=${d.selectFirst("meta[name=_bk]")?.attr("content")} br=${d.selectFirst("meta[name=_br]")?.attr("content")} bcLen=${bc.length} cerez=${cerez.keys}")
    val src = d.selectFirst("script[src*=_bcs]")?.attr("abs:src") ?: return@runBlocking
    val varyant = listOf(
        "cerezli" to mapOf("Accept" to "*/*"),
        "cerezli+secfetch" to mapOf("Accept" to "*/*", "Sec-Fetch-Dest" to "script", "Sec-Fetch-Mode" to "no-cors", "Sec-Fetch-Site" to "same-origin", "sec-ch-ua" to "\"Chromium\";v=\"140\", \"Google Chrome\";v=\"140\"", "sec-ch-ua-mobile" to "?0", "sec-ch-ua-platform" to "\"Windows\"", "Accept-Language" to "tr-TR,tr;q=0.9")
    )
    for ((ad, h) in varyant) {
        val js = runCatching { app.get(src, headers = UA + h, cookies = cerez, referer = bolum, timeout = 25) }.getOrNull()
        println("----- JS [$ad] kod=${js?.code} uzunluk=${js?.text?.length} cookies=${js?.cookies?.keys} -----")
        println(js?.text?.take(30000))
    }
    println("\n=== BİTTİ ===")
}
