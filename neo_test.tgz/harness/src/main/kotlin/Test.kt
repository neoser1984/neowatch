import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.runBlocking
import org.jsoup.Jsoup

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")
fun tek(s: String) = s.replace(Regex("\\s+"), " ").replace(Regex("<svg[\\s\\S]*?</svg>"), "<svg/>")

fun main(args: Array<String>) = runBlocking {
    println("=== oynatıcı türleri ===")
    // Son eklenen filmlerden 20 tanesinin oynatıcı türü
    val liste = Jsoup.parse(app.get("https://superfilmizle.org/film-izle/?sirala=yeni", headers = UA).text, "https://superfilmizle.org/")
    val filmler = listOf("https://superfilmizle.org/matrix/") + liste.select("a.group[href]").filter { it.selectFirst("h3") != null }.map { it.attr("abs:href") }.distinct().take(15)
    for (f in filmler) {
        val d = Jsoup.parse(app.get(f, headers = UA, timeout = 30).text, f)
        val kutu = d.selectFirst("[data-player]")
        val tur = kutu?.attr("data-player-type")
        val pv = d.selectFirst("[data-pv]")?.attr("data-pv")
        val ifr = d.select("[data-player] iframe, [data-player-shell] iframe").map { it.attr("src").ifBlank { it.attr("data-src") } }
        println("$f -> tür=$tur pv=$pv iframe=$ifr kaynak sekmeleri=${d.select("[data-player-shell] button, [data-source], [data-embed]").map { tek(it.text()).take(30) + "|" + it.attributes().joinToString(",") { a -> a.key } }.take(6)}")
        if (pv == null) println("   KUTU: " + (d.selectFirst("[data-player-shell]")?.outerHtml()?.let { tek(it) }?.take(2500) ?: "yok") + "\n   #player: " + (d.selectFirst("#player")?.outerHtml()?.let { tek(it) }?.take(1500) ?: "yok"))
    }
    println("\n=== BİTTİ ===")
}
