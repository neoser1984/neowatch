import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout

fun main(args: Array<String>) = runBlocking {
    println("=== SelcukFlix erişim testi ===")
    val uaMasa = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")
    for ((ad, h) in listOf("varsayilan UA" to emptyMap<String, String>(), "masaustu UA" to uaMasa)) {
        for (u in listOf("https://selcukflix.app/", "https://selcukflix.app/kesfet", "https://selcukflix.app/dizi/reacher")) {
            val r = runCatching { app.get(u, headers = h, timeout = 30) }
            val y = r.getOrNull()
            val t = y?.text ?: ""
            println("[$ad] GET $u -> ${y?.code} server=${y?.headers?.get("server")} cf-mitigated=${y?.headers?.get("cf-mitigated")} uzunluk=${t.length} baslik=${Regex("<title>([^<]*)</title>").find(t)?.groupValues?.get(1)?.take(70)} nextData=${t.contains("__NEXT_DATA__")} ${r.exceptionOrNull() ?: ""}")
            if (y != null && !t.contains("__NEXT_DATA__")) println("      gövde: " + t.replace(Regex("<script[\\s\\S]*?</script>|<style[\\s\\S]*?</style>"), "").replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").take(300))
        }
        val p = runCatching { app.post("https://selcukflix.app/api/bg/findSeries", params = mapOf("categoryIdsComma" to "9", "currentPage" to "1", "currentPageCount" to "24", "orderType" to "1", "languageId" to "-1", "releaseYearStart" to "1900", "releaseYearEnd" to "2100", "imdbPointMin" to "0", "imdbPointMax" to "10"), headers = h + mapOf("Accept" to "application/json, text/plain, */*"), referer = "https://selcukflix.app/kesfet", timeout = 30) }
        println("[$ad] POST findSeries -> ${p.getOrNull()?.code} server=${p.getOrNull()?.headers?.get("server")} cf-mitigated=${p.getOrNull()?.headers?.get("cf-mitigated")} | ${p.getOrNull()?.text?.take(120)} ${p.exceptionOrNull() ?: ""}")
    }
    val api = SelcukFlix()
    for (k in api.mainPage.take(6)) {
        val r = runCatching { withTimeout(60_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("EKLENTI ${k.name} -> ${l.size} ${r.exceptionOrNull() ?: ""} | ${l.take(2).joinToString { it.name }}")
    }
    println("\n=== BİTTİ ===")
}
