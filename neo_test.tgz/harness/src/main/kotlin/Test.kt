import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.runBlocking
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")
val ANA = "https://superfilmizle.org"

fun tek(s: String) = s.replace(Regex("\\s+"), " ")

suspend fun getir(url: String, ref: String? = null): Document? {
    val r = runCatching { app.get(url, headers = UA, referer = ref, timeout = 30) }
    val y = r.getOrNull()
    if (y == null) { println("GET $url -> HATA ${r.exceptionOrNull()}"); return null }
    println("GET $url -> ${y.code} son=${y.url} | başlık=${Jsoup.parse(y.text).title().take(90)} | uzunluk=${y.text.length}")
    return Jsoup.parse(y.text, y.url)
}

fun yollar(doc: Document) {
    val hrefs = doc.select("a[href]").map { it.attr("abs:href") }.filter { it.startsWith(ANA) }.distinct()
    val grup = hrefs.groupBy { it.removePrefix(ANA).trim('/').split("/").firstOrNull() ?: "" }
    grup.entries.sortedByDescending { it.value.size }.take(15).forEach { (k, v) -> println("   /$k (${v.size}): ${v.take(4).joinToString(" ")}") }
}

fun kartlar(doc: Document, desen: String): List<Element> {
    val linkler = doc.select("a[href*=$desen]").filter { it.selectFirst("img") != null || it.parent()?.selectFirst("img") != null }
    println("   '$desen' içeren görselli bağlantı sayısı: ${linkler.size}")
    linkler.firstOrNull()?.let { a ->
        var e: Element = a
        repeat(3) { e.parent()?.let { p -> if (p.select("a[href*=$desen]").size <= 2) e = p } }
        println("   İLK KART (üst öğe ${e.tagName()}.${e.className()}): " + tek(e.outerHtml()).take(2200))
    }
    return linkler
}

fun bagliam(html: String, kelimeler: List<String>, n: Int = 3) {
    for (k in kelimeler) {
        var i = html.indexOf(k); var say = 0
        while (i >= 0 && say < n) {
            println("   «$k» … " + tek(html.substring(maxOf(0, i - 250), minOf(html.length, i + 450))))
            i = html.indexOf(k, i + k.length); say++
        }
    }
}

fun main(args: Array<String>) = runBlocking {
    println("=== superfilmizle.org yapı araştırması ===")
    val ana = getir("$ANA/") ?: return@runBlocking
    yollar(ana)
    for (s in listOf("section", "div.swiper", "h2", "h3")) println("   [$s] ${ana.select(s).size}: " + ana.select(s).take(12).joinToString(" | ") { tek(it.ownText().ifBlank { it.text() }).take(60) })

    println("\n--- film listesi sayfası")
    val liste = getir("$ANA/film-izle/")
    liste?.let { yollar(it); kartlar(it, "/film/") ; kartlar(it, "-izle") }
    getir("$ANA/film-izle/page/2/")?.let { println("   sayfa2 görselli film: " + it.select("a[href]").count { a -> a.selectFirst("img") != null }) }

    println("\n--- kategori sayfası")
    getir("$ANA/category/aksiyon-filmleri/")?.let { yollar(it); println("   görselli bağlantı: " + it.select("a[href]").count { a -> a.selectFirst("img") != null }) }
    getir("$ANA/category/aksiyon-filmleri/page/2/")?.let { println("   s2 görselli bağlantı: " + it.select("a[href]").count { a -> a.selectFirst("img") != null }) }

    println("\n--- diziler / animeler")
    for (u in listOf("$ANA/dizi-izle/", "$ANA/diziler/", "$ANA/anime-izle/", "$ANA/animeler/")) getir(u)?.let { yollar(it) }

    // film sayfası
    val filmUrl = (liste ?: ana).select("a[href]").filter { it.selectFirst("img") != null }.map { it.attr("abs:href") }.firstOrNull { it.startsWith(ANA) && !it.contains("/category/") && !it.contains("/page/") }
    println("\n--- film sayfası: $filmUrl")
    if (filmUrl != null) {
        val r = app.get(filmUrl, headers = UA, timeout = 30)
        val fd = Jsoup.parse(r.text, r.url)
        println("   başlık=${fd.title()} h1=${fd.select("h1").text()}")
        println("   og:image=${fd.selectFirst("meta[property=og:image]")?.attr("content")} desc=${fd.selectFirst("meta[name=description]")?.attr("content")?.take(200)}")
        println("   iframe: " + fd.select("iframe").map { it.attr("src") + " / " + it.attr("data-src") })
        bagliam(r.text, listOf("<iframe", "data-src", "player", "embed", ".m3u8", "imdb", "Yönetmen", "Oyuncu", "ajax", "/api/", "data-id", "source", "alternatif", "Dublaj", "Altyaz"), 2)
        val ld = fd.select("script[type=application/ld+json]").map { tek(it.data()).take(1500) }
        println("   ld+json: $ld")
    }

    // dizi sayfası
    val diziListe = getir("$ANA/dizi-izle/") ?: getir("$ANA/diziler/")
    val diziUrl = diziListe?.select("a[href]")?.filter { it.selectFirst("img") != null }?.map { it.attr("abs:href") }?.firstOrNull { it.startsWith(ANA) && !it.contains("/category/") && !it.contains("/page/") }
    println("\n--- dizi sayfası: $diziUrl")
    if (diziUrl != null) {
        val r = app.get(diziUrl, headers = UA, timeout = 30)
        val dd = Jsoup.parse(r.text, r.url)
        println("   başlık=${dd.title()}")
        yollar(dd)
        bagliam(r.text, listOf("sezon", "Sezon", "bolum", "Bölüm", "episode", "season"), 2)
        val bolum = dd.select("a[href]").map { it.attr("abs:href") }.firstOrNull { it.contains("bolum") || it.contains("episode") || it.contains("sezon") }
        println("\n--- bölüm sayfası: $bolum")
        if (bolum != null) {
            val br = app.get(bolum, headers = UA, timeout = 30)
            val bd = Jsoup.parse(br.text, br.url)
            println("   başlık=${bd.title()} iframe=" + bd.select("iframe").map { it.attr("src") + " / " + it.attr("data-src") })
            bagliam(br.text, listOf("<iframe", "player", "embed", "data-id", "ajax"), 2)
        }
    }

    println("\n--- arama")
    getir("$ANA/ara?q=matrix")?.let { d -> println("   görselli bağlantı: " + d.select("a[href]").filter { it.selectFirst("img") != null }.take(8).joinToString(" ") { it.attr("abs:href") }) }
    println("\n=== BİTTİ ===")
}
