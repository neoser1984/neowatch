import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.jsoup.Jsoup

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

suspend fun dene(api: MainAPI, kategoriSayisi: Int = 4, arama: String? = null) {
    println("\n==================== ${api.name} (${api.mainUrl}) — kategori ${api.mainPage.size} ====================")
    var ilk: SearchResponse? = null
    for (k in api.mainPage.take(kategoriSayisi)) {
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("KAT ${k.name} -> ${l.size} hasNext=${r.getOrNull()?.hasNext} ${r.exceptionOrNull() ?: ""} | ${l.take(2).joinToString { "${it.name} ${it.url}" }}")
        if (ilk == null) ilk = l.firstOrNull { it.type != TvType.Movie } ?: l.firstOrNull()
    }
    if (arama != null) {
        val s = runCatching { api.search(arama) }
        println("ARAMA $arama -> ${s.getOrNull()?.size} ${s.exceptionOrNull() ?: ""} | ${s.getOrNull()?.take(3)?.joinToString { "${it.name} ${it.url}" }}")
    }
    val hedef = ilk ?: return
    val y = runCatching { withTimeout(120_000) { api.load(hedef.url) } }
    val yy = y.getOrNull()
    println("LOAD ${hedef.url} -> ${yy?.name} ${yy?.type} yıl=${yy?.year} poster=${yy?.posterUrl?.take(80)} ${y.exceptionOrNull() ?: ""}")
    val veri = when (yy) { is TvSeriesLoadResponse -> { println("   bölüm=${yy.episodes.size} ilk=${yy.episodes.firstOrNull()?.data}"); yy.episodes.firstOrNull()?.data }; is MovieLoadResponse -> yy.dataUrl; else -> null } ?: return
    val links = mutableListOf<ExtractorLink>(); val subs = mutableListOf<SubtitleFile>()
    val ok = runCatching { withTimeout(120_000) { api.loadLinks(veri, false, { subs.add(it) }, { links.add(it) }) } }
    println("   LINKS ok=${ok.getOrNull()} ${ok.exceptionOrNull() ?: ""} altyazı=${subs.size}")
    links.forEach { l -> val m = runCatching { app.get(l.url, headers = l.headers + mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} ${l.type} -> ${m?.code} ${m?.headers?.get("content-type")} | ${l.url.take(100)}") }
}

fun main(args: Array<String>) = runBlocking {
    println("=== JitPack yoklaması ===")
    val j = "https://jitpack.io/com/github/recloudstream"
    val adresler = listOf(
        "$j/gradle/gradle/master-SNAPSHOT/maven-metadata.xml",
        "$j/gradle/master-SNAPSHOT/maven-metadata.xml",
        "$j/gradle/gradle/maven-metadata.xml",
        "$j/gradle/maven-metadata.xml",
        "$j/gradle/32895aedb6/gradle-32895aedb6.pom",
        "$j/gradle/gradle/32895aedb6/gradle-32895aedb6.pom",
        "$j/gradle/81b1d424d2/gradle-81b1d424d2.pom",
        "$j/gradle/gradle/81b1d424d2/gradle-81b1d424d2.pom",
        "$j/gradle/gradle/81b1d424d2/gradle-81b1d424d2.module",
        "$j/gradle/gradle/32895aedb6/gradle-32895aedb6.module",
        "https://jitpack.io/api/builds/com.github.recloudstream/gradle",
        "https://api.github.com/repos/recloudstream/gradle/commits?per_page=8"
    )
    for (u in adresler) {
        val r = runCatching { app.get(u, headers = UA, timeout = 60) }
        val t = r.getOrNull()?.text ?: ""
        println("---- $u -> ${r.getOrNull()?.code} ${r.exceptionOrNull() ?: ""} (${t.length})")
        if (u.contains("api.github.com")) {
            Regex("\"sha\":\\s*\"([0-9a-f]{40})\"[\\s\\S]*?\"date\":\\s*\"([^\"]+)\"[\\s\\S]*?\"message\":\\s*\"([^\"]{0,90})").findAll(t).forEach { println("   ${it.groupValues[1].take(10)} ${it.groupValues[2]} ${it.groupValues[3]}") }
        } else println(t.take(1500))
    }
    println("\n=== BİTTİ ===")
}
