import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.runBlocking
import org.jsoup.Jsoup
import org.jsoup.nodes.Document

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

fun temiz(s: String) = s.replace(Regex("<script[\\s\\S]*?</script>|<style[\\s\\S]*?</style>"), "").replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()

suspend fun getir(url: String): Pair<String?, Document?> {
    val r = runCatching { app.get(url, headers = UA, timeout = 30) }
    val y = r.getOrNull()
    if (y == null) { println("GET $url -> HATA ${r.exceptionOrNull()}"); return null to null }
    val doc = Jsoup.parse(y.text, y.url)
    println("GET $url -> ${y.code} son=${y.url} | başlık=${doc.title().take(90)} | uzunluk=${y.text.length} | server=${y.headers["server"]}")
    return y.url to doc
}

fun ozet(doc: Document) {
    for (s in listOf("div.movie-preview-content", "span.movie-title a", "div.movie-preview", "article", "div.poster img", "div#vast iframe", "iframe", "div.title h1", "h1")) {
        println("   [$s] = ${doc.select(s).size}")
    }
    val kat = doc.select("a[href]").map { it.attr("abs:href") }.filter { it.contains("/category/") || it.contains("/kategori/") || it.contains("/tur/") || it.contains("/genre/") }.distinct()
    println("   kategori bağlantıları (${kat.size}): " + kat.take(60).joinToString(" "))
    val metin = doc.body()?.text() ?: ""
    println("   metin: " + metin.take(700))
}

fun main(args: Array<String>) = runBlocking {
    println("=== SuperFilmGeldi alan adı araştırması ===")
    val adaylar = listOf(
        "https://www.superfilmgeldi.me/", "https://superfilmgeldi.me/",
        "https://superfilmizle.org/", "https://superfilmgeldi.info/", "https://superfilmgeldi.net/",
        "https://superfilmgeldi.com/", "https://superfilmgeldi.pro/", "https://www.superfilmgeldi.biz/"
    )
    val iyi = mutableListOf<Pair<String, Document>>()
    for (a in adaylar) {
        val (son, doc) = getir(a)
        if (doc != null) {
            ozet(doc)
            if (doc.select("div.movie-preview-content").isNotEmpty() || doc.select("a[href*=/film/], a[href*=izle]").size > 10) iyi.add((son ?: a) to doc)
        }
        println()
    }
    for ((son, doc) in iyi) {
        println("\n######## AYRINTI: $son")
        val kart = doc.selectFirst("div.movie-preview-content") ?: doc.selectFirst("article") ?: doc.selectFirst("div.movie-preview")
        println("İLK KART HTML: " + (kart?.outerHtml()?.replace(Regex("\\s+"), " ")?.take(2500) ?: "yok"))
        val filmler = doc.select("div.movie-preview-content span.movie-title a, article a[href], a[href*=izle]").map { it.attr("abs:href") }.filter { it.startsWith("http") }.distinct()
        println("film bağlantıları: " + filmler.take(10).joinToString(" "))
        val film = filmler.firstOrNull { !it.contains("/category/") && !it.contains("/page/") } ?: continue
        val (_, fd) = getir(film)
        if (fd != null) {
            for (s in listOf("div.title h1", "div.poster img", "div.release a", "div.excerpt p", "div.categories a", "span.imdb-rating", "div.actor a", "div#vast iframe", "iframe", "div.film-content div.existing_item")) {
                val e = fd.select(s)
                println("   [$s] ${e.size} -> " + e.take(3).joinToString(" || ") { it.outerHtml().replace(Regex("\\s+"), " ").take(300) })
            }
            val ifr = fd.select("iframe").map { it.attr("abs:src").ifBlank { it.attr("data-src") } }
            println("   iframe adresleri: $ifr")
            val oynat = fd.select("div#vast, div.video-content, div.player, div#player").firstOrNull()
            println("   oynatıcı HTML: " + (oynat?.outerHtml()?.replace(Regex("\\s+"), " ")?.take(1500) ?: "yok"))
            val alt = fd.select("a[href*=?page], a[href*=/2/], div.alternative-links a, ul.parts a, div.keremiya_part a").map { it.text() + "=" + it.attr("abs:href") }
            println("   alternatif kaynak bağlantıları: " + alt.take(15))
        }
        // arama
        getir("${son.trimEnd('/')}/?s=matrix").second?.let { println("   arama [div.movie-preview-content]=${it.select("div.movie-preview-content").size} [article]=${it.select("article").size}") }
        getir("${son.trimEnd('/')}/page/2/").second?.let { println("   sayfa2 [div.movie-preview-content]=${it.select("div.movie-preview-content").size}") }
    }
    println("\n=== BİTTİ ===")
}
