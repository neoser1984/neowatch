import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout

data class Hedef(val api: MainAPI, val arama: String?, val dogrudan: List<String>)

fun main(args: Array<String>) = runBlocking {
    val hepsi = listOf(
        Hedef(DiziPal(), "game", listOf("https://dizipal2135.com/bolum/game-of-thrones-1-sezon-1-bolum")),
        Hedef(DiziPalOrjinal(), "spartacus", listOf("https://dizipalorjinal12.com/bolumler/spartacus-s1b1", "https://dizipalorjinal12.com/filmler/saklambac")),
        Hedef(DiziMom(), "guller", listOf("https://www.dizimom.wiki/guller-ve-gunahlar-36-bolum-izle/")),
        Hedef(DiziBox(), null, listOf("https://www.dizibox.live/ripley-1-sezon-1-bolum-izle/")),
        Hedef(KoreanTurk(), null, emptyList()),
        Hedef(SetFilmIzle(), "aşk", listOf("https://www.setfilmizle.ltd/film/ask-ve-yasam-1995-izle/")),
        Hedef(DiziKorea(), null, emptyList()),
        Hedef(WebDramaTurkey(), null, emptyList()),
        Hedef(Dizilla(), null, emptyList()),
    )

    val secim = args.toSet()
    for (h in hepsi) {
        if (secim.isNotEmpty() && h.api.name !in secim) continue
        runCatching { testEt(h) }.onFailure { println("!!! ${h.api.name} genel hata: $it") }
    }
    println("\n=== BİTTİ ===")
}

suspend fun ham(url: String) {
    val r = runCatching { app.get(url, timeout = 30) }
    val y = r.getOrNull()
    val baslik = y?.text?.let { Regex("""<title>([^<]*)</title>""").find(it)?.groupValues?.get(1) }
    println("HAM GET $url -> ${y?.code} | başlık=${baslik?.take(80)} | uzunluk=${y?.text?.length} ${r.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
}

suspend fun testEt(h: Hedef) {
    val api = h.api
    println("\n==================== ${api.name} (${api.mainUrl}) ====================")
    ham(api.mainUrl)

    var ilk: SearchResponse? = null
    val istek = api.mainPage.firstOrNull()
    if (istek != null) {
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(istek.name, istek.data, istek.horizontalImages)) } }
        val liste = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("ANA SAYFA [${istek.name}] -> ${liste.size} öğe ${r.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        liste.take(3).forEach { println("   - ${it.name} | ${it.url} | ${it.posterUrl}") }
        ilk = liste.firstOrNull()
    }

    if (h.arama != null) {
        val s = runCatching { withTimeout(60_000) { api.search(h.arama) } }
        println("ARAMA '${h.arama}' -> ${s.getOrNull()?.size} ${s.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        s.getOrNull()?.take(3)?.forEach { println("   - ${it.name} | ${it.url}") }
    }

    val veriler = mutableListOf<String>()
    if (ilk != null) {
        val y = runCatching { withTimeout(120_000) { api.load(ilk.url) } }
        val lr = y.getOrNull()
        if (lr == null) {
            println("LOAD ${ilk.url} -> null ${y.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        } else {
            when (lr) {
                is TvSeriesLoadResponse -> {
                    println("LOAD DİZİ '${lr.name}' bölüm=${lr.episodes.size} yıl=${lr.year} poster=${lr.posterUrl} konu=${lr.plot?.take(60)}")
                    lr.episodes.take(2).forEach { println("   ep S${it.season}E${it.episode} ${it.name} | ${it.data}") }
                    lr.episodes.firstOrNull()?.data?.let { veriler.add(it) }
                }
                is MovieLoadResponse -> {
                    println("LOAD FİLM '${lr.name}' yıl=${lr.year} poster=${lr.posterUrl} konu=${lr.plot?.take(60)}")
                    veriler.add(lr.dataUrl)
                }
                else -> println("LOAD ${lr::class.simpleName} '${lr.name}'")
            }
        }
    }
    veriler.addAll(h.dogrudan)

    for (veri in veriler.distinct()) {
        println("-- LOADLINKS $veri")
        val linkler = mutableListOf<ExtractorLink>()
        val r = runCatching {
            withTimeout(150_000) {
                api.loadLinks(veri, false, { println("   ALTYAZI ${it.lang} | ${it.url}") }, { linkler.add(it) })
            }
        }
        println("   dönüş=${r.getOrNull()} link=${linkler.size} ${r.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        for (l in linkler) {
            println("   LINK ${l.source} | ${l.name} | ${l.type} | ${l.url.take(160)} | ref=${l.referer} | h=${l.headers}")
            val basliklar = l.headers.toMutableMap()
            if (l.type != ExtractorLinkType.M3U8) basliklar["Range"] = "bytes=0-2047"
            val t = runCatching { app.get(l.url, referer = l.referer.ifBlank { null }, headers = basliklar, timeout = 30) }
            val yanit = t.getOrNull()
            val ozet = if (l.type == ExtractorLinkType.M3U8) yanit?.text?.take(150)?.replace("\n", " ⏎ ") else "${yanit?.headers?.get("Content-Type")} ${yanit?.headers?.get("Content-Length")}"
            println("      erişim -> ${yanit?.code} $ozet ${t.exceptionOrNull()?.let { "HATA $it" } ?: ""}")
        }
    }
}
