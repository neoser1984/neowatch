import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.jsoup.Jsoup

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

suspend fun dene(api: MainAPI, kategoriSayisi: Int = 4, arama: String? = null) {
    println("\n==================== ${api.name} (${api.mainUrl}) — kategori ${api.mainPage.size} ====================")
    var ilk: SearchResponse? = null
    for (k in api.mainPage.take(kategoriSayisi)) {
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("KAT ${k.name} -> ${l.size} hasNext=${r.getOrNull()?.hasNext} ${r.exceptionOrNull() ?: ""} | ${l.take(2).joinToString { "${it.name} ${it.url}" }}")
        if (ilk == null) ilk = l.firstOrNull { it.type != TvType.Movie } ?: l.firstOrNull()
    }
    if (arama != null) {
        val s = runCatching { api.search(arama) }
        println("ARAMA $arama -> ${s.getOrNull()?.size} ${s.exceptionOrNull() ?: ""} | ${s.getOrNull()?.take(3)?.joinToString { "${it.name} ${it.url}" }}")
    }
    val hedef = ilk ?: return
    val y = runCatching { withTimeout(120_000) { api.load(hedef.url) } }
    val yy = y.getOrNull()
    println("LOAD ${hedef.url} -> ${yy?.name} ${yy?.type} yıl=${yy?.year} poster=${yy?.posterUrl?.take(80)} ${y.exceptionOrNull() ?: ""}")
    val veri = when (yy) { is TvSeriesLoadResponse -> { println("   bölüm=${yy.episodes.size} ilk=${yy.episodes.firstOrNull()?.data}"); yy.episodes.firstOrNull()?.data }; is MovieLoadResponse -> yy.dataUrl; else -> null } ?: return
    val links = mutableListOf<ExtractorLink>(); val subs = mutableListOf<SubtitleFile>()
    val ok = runCatching { withTimeout(120_000) { api.loadLinks(veri, false, { subs.add(it) }, { links.add(it) }) } }
    println("   LINKS ok=${ok.getOrNull()} ${ok.exceptionOrNull() ?: ""} altyazı=${subs.size}")
    links.forEach { l -> val m = runCatching { app.get(l.url, headers = l.headers + mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} ${l.type} -> ${m?.code} ${m?.headers?.get("content-type")} | ${l.url.take(100)}") }
}

suspend fun linkleriDene(api: MainAPI, veri: String) {
    val links = mutableListOf<ExtractorLink>(); val subs = mutableListOf<SubtitleFile>()
    val ok = runCatching { withTimeout(120_000) { api.loadLinks(veri, false, { subs.add(it) }, { links.add(it) }) } }
    println("   LINKS ok=${ok.getOrNull()} ${ok.exceptionOrNull() ?: ""} adet=${links.size} altyazı=${subs.size}")
    links.take(6).forEach { l -> val m = runCatching { app.get(l.url, headers = l.headers + mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} ${l.type} -> ${m?.code} ${m?.headers?.get("content-type")} | ${l.url.take(140)}") }
}

fun main(args: Array<String>) = runBlocking {
    println("=== InatBox / ContentX / DiziPalGuncel testi ===")
    // 1) DiziPalGuncel oynatıcısı (dplayer82 / ContentX)
    val iframe = "https://sn.dplayer82.site/iframe.php?v=07c45311062e1c9818feb861a49a545c"
    val ham = runCatching { app.get(iframe, referer = "https://dizipal1592.com/", headers = UA, timeout = 25) }.getOrNull()
    println("[iframe] ${ham?.code} uzunluk=${ham?.text?.length} openPlayer=${ham?.text?.contains("openPlayer")} başlık=${ham?.document?.title()}")
    val cx = mutableListOf<ExtractorLink>(); val cxs = mutableListOf<SubtitleFile>()
    runCatching { ContentXGenel().getUrl(iframe, "https://dizipal1592.com/", { cxs.add(it) }, { cx.add(it) }) }.onFailure { println("ContentX hata $it") }
    println("[ContentX] link=${cx.size} altyazı=${cxs.size} ${cxs.joinToString { it.lang }}")
    cx.forEach { l -> val m = runCatching { app.get(l.url, headers = mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} -> ${m?.code} m3u=${m?.text?.startsWith("#EXTM3U")} | ${l.url.take(120)}") }
    for (u in listOf("https://dizipal1592.com/yabanci-dizi-izle", "https://dizipal1592.com/bolum/the-walking-dead-1x1-c31")) {
        val r = runCatching { app.get(u, headers = UA, timeout = 25) }.getOrNull()
        println("[dizipal1592] $u -> ${r?.code} başlık=${r?.document?.title()?.take(60)} uzunluk=${r?.text?.length}")
    }

    // 2) InatBox
    val api = InatBox()
    for (kat in listOf("Yerli Filmler", "Netflix", "Sinema", "Yabancı Diziler")) {
        val k = api.mainPage.firstOrNull { it.name == kat } ?: continue
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("\n##### InatBox KAT $kat -> ${l.size} ${r.exceptionOrNull() ?: ""}")
        l.take(2).forEach { println("   item: ${it.name} :: ${it.url.take(400)}") }
        val hedef = l.firstOrNull() ?: continue
        val y = runCatching { withTimeout(90_000) { api.load(hedef.url) } }
        val yy = y.getOrNull()
        println("   LOAD -> ${yy?.name} ${yy?.type} ${y.exceptionOrNull() ?: ""}")
        val veri = when (yy) { is TvSeriesLoadResponse -> { println("   bölüm=${yy.episodes.size}"); yy.episodes.firstOrNull()?.data }; is MovieLoadResponse -> yy.dataUrl; is LiveStreamLoadResponse -> yy.dataUrl; else -> null } ?: continue
        println("   veri: ${veri.take(600)}")
        linkleriDene(api, veri)
    }
    println("\n=== BİTTİ ===")
}
