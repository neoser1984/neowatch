import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.jsoup.Jsoup
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")
fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
fun tek(s: String) = s.replace(Regex("\\s+"), " ")

suspend fun hamImzali(url: String) {
    val r = SecureRandom()
    val harf = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    val anahtar = (1..16).map { harf[r.nextInt(harf.length)] }.joinToString("")
    val govde = "1=$anahtar&0=$anahtar"
    val yol = java.net.URI(url).rawPath
    var fark = 0L
    repeat(2) { deneme ->
        val zaman = (System.currentTimeMillis() / 1000 + fark).toString()
        val nonce = hex(ByteArray(16).also { r.nextBytes(it) })
        val sha = hex(MessageDigest.getInstance("SHA-256").digest(govde.toByteArray()))
        val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec("x7kkk0qmqz63kj68tla5i7u26192v7zqnnddhjgm".toByteArray(), "HmacSHA256")) }
        val imza = hex(mac.doFinal("POST\n$yol\n$zaman\n$nonce\n$sha".toByteArray()))
        val y = runCatching { app.post(url, headers = mapOf("User-Agent" to "speedrestapi", "X-Requested-With" to "com.bp.box", "Referer" to "https://speedrestapi.com/", "Content-Type" to "application/x-www-form-urlencoded; charset=UTF-8", "Cache-Control" to "no-cache", "X-Ts" to zaman, "X-Nc" to nonce, "X-Sg" to imza), requestBody = govde.toRequestBody("application/x-www-form-urlencoded; charset=UTF-8".toMediaType()), timeout = 30) }
        val yy = y.getOrNull()
        val t = yy?.text ?: ""
        println("   HAM [$deneme] $url -> ${yy?.code} x-st=${yy?.headers?.get("x-st")} server=${yy?.headers?.get("server")} uzunluk=${t.length} ${y.exceptionOrNull() ?: ""} | ${tek(t.replace(Regex("<[^>]+>"), " ")).take(200)}")
        val c = InatIstek.coz(t, listOf(anahtar, InatIstek.VARSAYILAN_ANAHTAR))
        println("   çözüm: ${c?.take(300) ?: "YOK"}")
        val st = yy?.headers?.get("x-st")?.toLongOrNull()
        if (yy?.code == 403 && st != null) fark = st - System.currentTimeMillis() / 1000 else return
    }
}

fun main(args: Array<String>) = runBlocking {
    println("=== InatBox ===")
    hamImzali("https://dizilabmedia.click/CDN/001/002/dizilab/v2/ct.php")
    hamImzali("https://diziboxen.help/CDN/001/002/dizibox/v2/tv/ulusal.php")
    val harita = runCatching { InatIstek.kategoriHaritasi() }.getOrNull().orEmpty()
    println("kategori haritası: ${harita.size} | ${harita.entries.take(6).joinToString { "${it.key}=${it.value}" }}")
    val api = InatBox()
    for (ad in listOf("Ulusal", "Yabancı Diziler", "Sinema", "Netflix")) {
        val k = api.mainPage.firstOrNull { it.name == ad } ?: continue
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("KAT $ad -> ${l.size} ${r.exceptionOrNull() ?: ""} | ${l.take(3).joinToString { it.name }}")
        if (ad == "Ulusal" && l.isNotEmpty()) {
            val y = runCatching { api.load(l.first().url) }.getOrNull()
            val veri = (y as? LiveStreamLoadResponse)?.dataUrl ?: (y as? MovieLoadResponse)?.dataUrl
            val links = mutableListOf<ExtractorLink>()
            if (veri != null) runCatching { withTimeout(60_000) { api.loadLinks(veri, false, {}, { links.add(it) }) } }
            println("   ilk kanal ${l.first().name}: link=${links.size} ${links.firstOrNull()?.url?.take(90)}")
        }
    }

    println("\n=== DiziPal alan adları ===")
    for (n in (2138..2146).map { "https://dizipal$it.com/" } + (1588..1596).map { "https://dizipal$it.com/" }) {
        val r = runCatching { app.get(n, headers = UA, timeout = 20) }
        val y = r.getOrNull()
        val t = y?.text ?: ""
        println("$n -> ${y?.code} son=${y?.url} başlık=${Jsoup.parse(t).title().take(60)} uzunluk=${t.length} ${r.exceptionOrNull()?.javaClass?.simpleName ?: ""}")
    }

    println("\n=== KoreanTurk (koreanturk.tv) ===")
    val b = Jsoup.parse(app.get("https://koreanturk.tv/bolum/perfect-crown-1-bolum/", headers = UA).text, "https://koreanturk.tv/")
    val ifr = b.select("iframe").map { it.attr("abs:src").ifBlank { it.attr("abs:data-src") } }
    println("bölüm iframe: $ifr")
    println("bölüm player alanı: " + tek(b.select("div[class*=player], div[class*=video], div.tab-content, ul[class*=part], div[class*=source]").take(3).joinToString(" || ") { it.outerHtml() }).take(2500))
    for (f in ifr.filter { it.startsWith("http") }.take(2)) {
        val p = runCatching { app.get(f, headers = UA, referer = "https://koreanturk.tv/", timeout = 30) }.getOrNull()
        val pt = p?.text ?: ""
        println("PLAYER $f -> ${p?.code} uzunluk=${pt.length}")
        println("   gövde: " + tek(pt).take(3000))
        println("   m3u8/mp4/file: " + Regex("""(https?:[^"'\s]+\.(?:m3u8|mp4)[^"'\s]*)|file["']?\s*[:=]\s*["']([^"']+)|source[^>]*src=["']([^"']+)""").findAll(pt).map { it.value }.take(10).toList())
    }
    val film = Jsoup.parse(app.get("https://koreanturk.tv/second-sister/", headers = UA).text, "https://koreanturk.tv/")
    println("film başlık=${film.select("h1").text()} iframe=${film.select("iframe").map { it.attr("abs:src") }}")
    for (u in listOf("https://koreanturk.tv/dizi-arsivi/", "https://koreanturk.tv/dizi-arsivi/page/2/", "https://koreanturk.tv/film-arsivi/", "https://koreanturk.tv/dizi-kategori/aile-dizileri-izle/", "https://koreanturk.tv/dizi-kategori/aile-dizileri-izle/page/2/", "https://koreanturk.tv/page/2/", "https://koreanturk.tv/?s=perfect", "https://koreanturk.tv/category/aksiyon-kore-filmleri-izle/")) {
        val d = Jsoup.parse(runCatching { app.get(u, headers = UA).text }.getOrDefault(""), "https://koreanturk.tv/")
        println("$u -> series-box=${d.select("div.series-box").size} movie-box=${d.select("div.movie-box").size} ep-box=${d.select("div.ep-box").size} ilk=${d.select("div.series-box a, div.movie-box a, div.ep-box a").firstOrNull()?.attr("abs:href")} sayfa=${d.select("a[href*=/page/]").map { it.attr("abs:href") }.distinct().take(3)}")
    }
    val dz = Jsoup.parse(app.get("https://koreanturk.tv/dizi/perfect-crown/", headers = UA).text, "https://koreanturk.tv/")
    val ek = dz.select("a[href*=/bolum/]").firstOrNull()
    var e = ek
    repeat(3) { e?.parent()?.let { p -> if (p.select("a[href*=/bolum/]").size <= 2) e = p } }
    println("dizi sayfası bölüm kutusu: " + tek(e?.outerHtml() ?: "yok").take(1200))
    println("dizi bilgi: h1=${dz.select("h1").text()} poster=${dz.selectFirst("div.poster img, div.series-poster img, div.img img")?.attr("abs:src")} yıl=${dz.select("a[href*=/yapim/]").text()} tür=${dz.select("a[href*=/dizi-kategori/]").map { it.text() }} açıklama=${dz.selectFirst("meta[property=og:description]")?.attr("content")?.take(80)}")
    println("\n=== BİTTİ ===")
}
