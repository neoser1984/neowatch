import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.jsoup.Jsoup

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

val EKLENTILER = listOf("AnimeciX", "BelgeselX", "CanliTV", "CizgiMax", "DiziBal", "DiziBox", "DiziKorea", "DiziMom", "DiziPal", "DiziPalGuncel", "DiziPalOrjinal", "DiziYou", "Dizilla", "FilmMakinesi", "FilmModu", "FullHDFilm", "FullHDFilmizlesene", "HDFilmCehennemi", "InatBox", "JetFilmizle", "KoreanTurk", "KultFilmler", "NetflixMirror", "RareFilmm", "RecTV", "SelcukFlix", "SetFilmIzle", "SezonlukDizi", "SinemaCX", "SuperFilmGeldi", "TurkAnime", "UgurFilm", "WebDramaTurkey", "WebteIzle", "YouTube")

// Kodu test düzeneğinde derlenmeyenler ve PR #4'teki aday adresler: yalnızca ham kontrol
val HAM = listOf(
    "https://watch2movies.net",
    "https://dizipal2145.com", "https://dizipalorjinal18.com", "https://superfilmizle.click"
)

fun hata(t: Throwable?) = t?.let { "HATA ${it.javaClass.simpleName}: ${it.message?.take(90)}" } ?: ""

suspend fun hamKontrol(u: String): String {
    val r1 = runCatching { app.get(u, headers = UA, allowRedirects = false, timeout = 20) }
    val c1 = r1.getOrNull() ?: return "ham=YOK ${hata(r1.exceptionOrNull())}"
    val sb = StringBuilder("ham=${c1.code} loc=${c1.headers["location"] ?: "-"}")
    var metin = c1.text
    if (c1.code in 300..399) {
        val r2 = runCatching { app.get(u, headers = UA, timeout = 25) }
        val c2 = r2.getOrNull()
        sb.append(" | son=${c2?.url} ${c2?.code} ${hata(r2.exceptionOrNull())}")
        metin = c2?.text ?: ""
    }
    val d = Jsoup.parse(metin)
    sb.append(" | başlık='${d.title().take(60)}' uzunluk=${metin.length} canonical=${d.selectFirst("link[rel=canonical]")?.attr("href") ?: "-"}")
    return sb.toString()
}

suspend fun eklentiTest(ad: String): String {
    val sb = StringBuilder()
    val api = runCatching { Class.forName("com.neowatch.${ad.lowercase()}.$ad").getDeclaredConstructor().newInstance() as MainAPI }
        .getOrElse { return "### $ad: OLUŞTURULAMADI ${hata(it)}" }
    sb.appendLine("### $ad (${api.mainUrl}) kategori=${api.mainPage.size}")
    if (api.mainUrl.startsWith("http")) sb.appendLine("  " + hamKontrol(api.mainUrl))
    var ilk: SearchResponse? = null
    for (k in api.mainPage.take(2)) {
        val r = runCatching { withTimeout(60_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        sb.appendLine("  KAT ${k.name} -> ${l.size} ${hata(r.exceptionOrNull())} | ${l.take(2).joinToString { it.name.take(40) }}")
        if (ilk == null) ilk = l.firstOrNull { it.type != TvType.Live } ?: l.firstOrNull()
    }
    val hedef = ilk ?: return sb.toString()
    val y = runCatching { withTimeout(60_000) { api.load(hedef.url) } }
    val yy = y.getOrNull()
    val veri = when (yy) {
        is TvSeriesLoadResponse -> yy.episodes.firstOrNull()?.data
        is AnimeLoadResponse    -> yy.episodes.values.flatten().firstOrNull()?.data
        is MovieLoadResponse    -> yy.dataUrl
        is LiveStreamLoadResponse -> yy.dataUrl
        else -> null
    }
    val bolum = when (yy) { is TvSeriesLoadResponse -> yy.episodes.size; is AnimeLoadResponse -> yy.episodes.values.sumOf { it.size }; else -> -1 }
    sb.appendLine("  LOAD ${hedef.name.take(40)} -> ${yy?.name?.take(40)} ${yy?.type} bölüm=$bolum ${hata(y.exceptionOrNull())}")
    if (veri != null) {
        val links = mutableListOf<ExtractorLink>()
        val ok = runCatching { withTimeout(70_000) { api.loadLinks(veri, false, {}, { links.add(it) }) } }
        sb.appendLine("  LINKS ok=${ok.getOrNull()} adet=${links.size} ${hata(ok.exceptionOrNull())} | ${links.take(3).joinToString { it.name.take(25) + " " + it.url.substringAfter("://").substringBefore("/") }}")
    }
    return sb.toString()
}

fun adaylar(): Map<String, List<String>> {
    val tld = listOf("com","net","org","co","cc","tv","to","io","pro","vip","site","live","club","top","me","xyz","sbs","lol","one","biz","click","link","app","info","icu","cx","ws","pw","life","film","watch","nl","in","de","day","fun","art","mobi","plus","now","ltd","cfd","bond","skin","media","bz","so","gg","is","la","lt","ru","se","tr","cafe","run","men","best","video","tube","stream","world","online","store","games","wiki","rest","homes","boats","autos","beauty","quest","makeup","hair","lat","ink","im","ac","sh","st","su","fm","am","ma","ms","ae")
    fun t(ad: String) = tld.map { "https://$ad.$it" }
    fun n(ad: String, son: String, aralik: IntRange) = aralik.map { "https://$ad$it.$son" }
    return linkedMapOf(
        "DiziMom"    to t("dizimom") + t("dizidad") + t("www.dizimom") + n("dizimom", "com", 1..12) + n("dizidad", "com", 1..6) + n("dizimom", "cafe", 1..5),
        "TurkAnime"  to t("turkanime") + t("www.turkanime") + n("turkanime", "com", 1..6) + n("turkanime", "net", 1..6) + n("turkanime", "tv", 1..4),
        "UgurFilm"   to n("ugurfilm", "com", 26..40) + n("ugurfilm", "net", 1..15) + n("ugurfilm", "org", 1..10) + n("ugurfilm", "xyz", 1..10) + n("ugurfilm", "top", 1..10) + t("ugurfilmizle") + t("www.ugurfilm"),
        "FullHDFilm" to t("fullhdfilm") + t("www.fullhdfilm") + n("fullhdfilm", "site", 1..12) + n("fullhdfilm", "pro", 1..12) + n("fullhdfilm", "com", 10..20) + t("fullhdfilmler") + t("fullhd-film"),
        "NetflixMirror" to listOf("https://net12.cc/home", "https://net2.cc/home", "https://net77.cc/home", "https://net79.cc/home", "https://netmirror.gg", "https://tv.imgcdn.kim/newtv", "https://iosmirror.cc/home"),
        "Watch2Movies" to listOf("https://watch2movies.cc", "https://watch2movies.cc/home", "https://watch2movies.cc/movie")
    )
}

suspend fun adayKontrol(u: String): String? {
    val r = runCatching { app.get(u, headers = UA, allowRedirects = false, timeout = 12) }
    val c = r.getOrNull() ?: return null   // çözülemeyen / bağlanamayan
    val t = c.text
    val d = Jsoup.parse(t)
    return "$u -> ${c.code} loc=${c.headers["location"] ?: "-"} başlık='${d.title().take(60)}' uzunluk=${t.length}"
}

fun main(args: Array<String>) = runBlocking {
    android.util.Log.sessiz = true
    println("=== Aday alan adları ===")
    val sem = Semaphore(40)
    for ((ad, liste) in adaylar()) {
        val sonuc = liste.distinct().map { u -> async(Dispatchers.IO) { sem.withPermit { runCatching { withTimeout(20_000) { adayKontrol(u) } }.getOrNull() } } }.awaitAll().filterNotNull()
        println("\n##### $ad (${liste.size} aday, ${sonuc.size} yanıt)")
        sonuc.forEach { println("  " + it) }
    }

    println("\n=== Ayrıntılı eklenti testleri ===")
    android.util.Log.sessiz = false
    for (ad in listOf<String>()) {
        println(runCatching { withTimeout(200_000) { eklentiTest(ad) } }.getOrElse { "### $ad: ZAMAN AŞIMI/HATA ${hata(it)}" })
    }
    println("\n=== BİTTİ ===")
}
