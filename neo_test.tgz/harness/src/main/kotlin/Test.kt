import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.jsoup.Jsoup
import com.neowatch.jetfilmizle.VideoPark
import com.neowatch.jetfilmizle.PlayerX

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

val EKLENTILER = listOf("AnimeciX", "BelgeselX", "CanliTV", "CizgiMax", "DiziBal", "DiziBox", "DiziKorea", "DiziMom", "DiziPal", "DiziPalGuncel", "DiziPalOrjinal", "DiziYou", "Dizilla", "FilmMakinesi", "FilmModu", "FullHDFilm", "FullHDFilmizlesene", "HDFilmCehennemi", "InatBox", "JetFilmizle", "KoreanTurk", "KultFilmler", "NetflixMirror", "RareFilmm", "RecTV", "SelcukFlix", "SetFilmIzle", "SezonlukDizi", "SinemaCX", "SuperFilmGeldi", "TurkAnime", "UgurFilm", "WebDramaTurkey", "WebteIzle", "YouTube")

// Kodu test düzeneğinde derlenmeyenler ve PR #4'teki aday adresler: yalnızca ham kontrol
val HAM = listOf(
    "https://watch2movies.net",
    "https://dizipal2145.com", "https://dizipalorjinal18.com", "https://superfilmizle.click"
)

fun hata(t: Throwable?) = t?.let { "HATA ${it.javaClass.simpleName}: ${it.message?.take(90)}" } ?: ""

suspend fun hamKontrol(u: String): String {
    val r1 = runCatching { app.get(u, headers = UA, allowRedirects = false, timeout = 20) }
    val c1 = r1.getOrNull() ?: return "ham=YOK ${hata(r1.exceptionOrNull())}"
    val sb = StringBuilder("ham=${c1.code} loc=${c1.headers["location"] ?: "-"}")
    var metin = c1.text
    if (c1.code in 300..399) {
        val r2 = runCatching { app.get(u, headers = UA, timeout = 25) }
        val c2 = r2.getOrNull()
        sb.append(" | son=${c2?.url} ${c2?.code} ${hata(r2.exceptionOrNull())}")
        metin = c2?.text ?: ""
    }
    val d = Jsoup.parse(metin)
    sb.append(" | başlık='${d.title().take(60)}' uzunluk=${metin.length} canonical=${d.selectFirst("link[rel=canonical]")?.attr("href") ?: "-"}")
    return sb.toString()
}

suspend fun eklentiTest(ad: String): String {
    val sb = StringBuilder()
    val api = runCatching { Class.forName("com.neowatch.${ad.lowercase()}.$ad").getDeclaredConstructor().newInstance() as MainAPI }
        .getOrElse { return "### $ad: OLUŞTURULAMADI ${hata(it)}" }
    sb.appendLine("### $ad (${api.mainUrl}) kategori=${api.mainPage.size}")
    if (api.mainUrl.startsWith("http")) sb.appendLine("  " + hamKontrol(api.mainUrl))
    var ilk: SearchResponse? = null
    for (k in api.mainPage.take(2)) {
        val r = runCatching { withTimeout(60_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        sb.appendLine("  KAT ${k.name} -> ${l.size} ${hata(r.exceptionOrNull())} | ${l.take(2).joinToString { it.name.take(40) }}")
        if (ilk == null) ilk = l.firstOrNull { it.type != TvType.Live } ?: l.firstOrNull()
    }
    val hedef = ilk ?: return sb.toString()
    val y = runCatching { withTimeout(60_000) { api.load(hedef.url) } }
    val yy = y.getOrNull()
    val veri = when (yy) {
        is TvSeriesLoadResponse -> yy.episodes.firstOrNull()?.data
        is AnimeLoadResponse    -> yy.episodes.values.flatten().firstOrNull()?.data
        is MovieLoadResponse    -> yy.dataUrl
        is LiveStreamLoadResponse -> yy.dataUrl
        else -> null
    }
    val bolum = when (yy) { is TvSeriesLoadResponse -> yy.episodes.size; is AnimeLoadResponse -> yy.episodes.values.sumOf { it.size }; else -> -1 }
    sb.appendLine("  LOAD ${hedef.name.take(40)} -> ${yy?.name?.take(40)} ${yy?.type} bölüm=$bolum ${hata(y.exceptionOrNull())}")
    if (veri != null) {
        val links = mutableListOf<ExtractorLink>()
        val ok = runCatching { withTimeout(70_000) { api.loadLinks(veri, false, {}, { links.add(it) }) } }
        sb.appendLine("  LINKS ok=${ok.getOrNull()} adet=${links.size} ${hata(ok.exceptionOrNull())} | ${links.take(3).joinToString { it.name.take(25) + " " + it.url.substringAfter("://").substringBefore("/") }}")
    }
    return sb.toString()
}

suspend fun yapiDok(u: String, ref: String? = null, sinir: Int = 22000, post: Map<String, String>? = null) {
    val r = runCatching {
        if (post != null) app.post(u, headers = UA + mapOf("X-Requested-With" to "XMLHttpRequest"), referer = ref, data = post, timeout = 25)
        else app.get(u, headers = UA, referer = ref, timeout = 25)
    }
    val c = r.getOrNull()
    println("\n######## $u -> ${c?.code} ${hata(r.exceptionOrNull())} son=${c?.url}")
    if (c == null) return
    val d = Jsoup.parse(c.text, u)
    println("TITLE: ${d.title()}")
    d.select("script[type=application/ld+json]").forEach { println("LDJSON: " + it.data().replace(Regex("\\s+"), " ").take(1500)) }
    d.select("script:not([src])").forEach { sc -> val t = sc.data(); if (Regex("iframe|player|source|embed|ajax|fetch\\(|\\.m3u8|episode|bolum", RegexOption.IGNORE_CASE).containsMatchIn(t) && t.length < 6000) println("SCRIPT: " + t.replace(Regex("\\s+"), " ").take(2500)) }
    d.select("script,style,svg,noscript,link,meta,head").remove()
    d.select("*").forEach { e -> e.attributes().asList().filter { it.key == "style" || it.key.startsWith("aria-") || it.key == "srcset" || it.key == "sizes" }.forEach { e.removeAttr(it.key) } }
    val govde = d.body()?.html()?.replace(Regex("\\s+"), " ")?.replace(Regex("> <"), "><") ?: ""
    println("BODY(${govde.length}): " + govde.take(sinir))
}

suspend fun aramaTest(ad: String, sorgu: String): String {
    val api = runCatching { Class.forName("com.neowatch.${ad.lowercase()}.$ad").getDeclaredConstructor().newInstance() as MainAPI }.getOrElse { return "ARAMA $ad: OLUŞTURULAMADI" }
    val r = runCatching { withTimeout(60_000) { api.search(sorgu) } }
    val l = r.getOrNull().orEmpty()
    return "  ARAMA $ad '$sorgu' -> ${l.size} ${hata(r.exceptionOrNull())} | ${l.take(3).joinToString { it.name.take(30) + " " + it.url.substringAfter("://").take(60) }}"
}

suspend fun hamDok(u: String, ref: String?, sinir: Int = 12000) {
    val r = runCatching { app.get(u, headers = UA + mapOf("Sec-Fetch-Dest" to "iframe"), referer = ref, timeout = 25) }
    val c = r.getOrNull()
    println("\n######## HAM $u (ref=$ref) -> ${c?.code} ${hata(r.exceptionOrNull())} son=${c?.url}")
    if (c == null) return
    val t = c.text
    println("UZUNLUK ${t.length}")
    println(t.replace(Regex("\\s+"), " ").take(sinir))
}

suspend fun scriptDok(u: String, ref: String?, sinir: Int = 40000) {
    val r = runCatching { app.get(u, headers = UA + mapOf("Sec-Fetch-Dest" to "iframe"), referer = ref, timeout = 25) }
    val c = r.getOrNull()
    println("\n######## SCRIPT $u (ref=$ref) -> ${c?.code} ${hata(r.exceptionOrNull())} son=${c?.url}")
    if (c == null) return
    val d = Jsoup.parse(c.text, u)
    println("SRCS: " + d.select("script[src]").joinToString(" ") { it.attr("abs:src") })
    println("IFRAMES: " + d.select("iframe").joinToString(" ") { it.attr("abs:src") })
    val sb = StringBuilder()
    d.select("script:not([src])").forEach { sb.append("\n<<SC>> ").append(it.data().replace(Regex("\\s+"), " ")) }
    println(sb.toString().take(sinir))
    d.select("script,style,svg,noscript,link,meta,head").remove()
    println("BODY: " + (d.body()?.html()?.replace(Regex("\\s+"), " ") ?: "").take(3000))
}

fun main(args: Array<String>) = runBlocking {
    android.util.Log.sessiz = true
    println("=== Eklenti testleri ===")
    for (ad in listOf("DiziMom", "YouTube", "TurkAnime")) println(eklentiTest(ad))
    println("=== Arama ===")
    for ((ad, q) in listOf("BelgeselX" to "titanik", "BelgeselX" to "osmanlı", "YouTube" to "barış manço")) println(aramaTest(ad, q))
    println("=== VideoPark / PlayerX ===")
    for (u in listOf("https://videopark.top/vip/?id=965038", "https://videopark.top/oplayer/?id=965038", "https://videopark.top/go/?id=965025", "https://playerx.info/?id=23056")) {
        val links = mutableListOf<com.lagradost.cloudstream3.utils.ExtractorLink>()
        val subs  = mutableListOf<String>()
        val r = runCatching { withTimeout(60_000) {
            if (u.contains("playerx")) PlayerX.coz(u, "Test", "https://jetfilmizle.app/", { subs.add(it.lang + " " + it.url.take(60)) }, { links.add(it) })
            else VideoPark.coz(u, "Test", "https://jetfilmizle.app/", { links.add(it) })
        } }
        println("  $u -> ${r.getOrNull()} ${hata(r.exceptionOrNull())} links=${links.size} subs=${subs.size}")
        for (l in links.take(4)) {
            val h = runCatching { app.get(l.url, referer = l.referer, headers = l.headers, timeout = 20) }.getOrNull()
            println("     ${l.name} ${l.type} ${l.url.take(110)} -> ${h?.code} ${h?.headers?.get("content-type")} ${h?.text?.take(80)?.replace("\n", " ")}")
        }
    }
    println("=== Ham dökümler ===")
    scriptDok("https://streamcorecdn.com/dizi/127532/1/1?sid=turkanime.live", "https://turkanime.live/", 60000)
    println("\n=== BİTTİ ===")
}
