import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.runBlocking
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")
val ANA = "https://superfilmizle.org"

fun tek(s: String) = s.replace(Regex("\\s+"), " ")

suspend fun getir(url: String, ref: String? = null): Document? {
    val r = runCatching { app.get(url, headers = UA, referer = ref, timeout = 30) }
    val y = r.getOrNull()
    if (y == null) { println("GET $url -> HATA ${r.exceptionOrNull()}"); return null }
    println("GET $url -> ${y.code} son=${y.url} | başlık=${Jsoup.parse(y.text).title().take(90)} | uzunluk=${y.text.length}")
    return Jsoup.parse(y.text, y.url)
}

fun yollar(doc: Document) {
    val hrefs = doc.select("a[href]").map { it.attr("abs:href") }.filter { it.startsWith(ANA) }.distinct()
    val grup = hrefs.groupBy { it.removePrefix(ANA).trim('/').split("/").firstOrNull() ?: "" }
    grup.entries.sortedByDescending { it.value.size }.take(15).forEach { (k, v) -> println("   /$k (${v.size}): ${v.take(4).joinToString(" ")}") }
}

fun kartlar(doc: Document, desen: String): List<Element> {
    val linkler = doc.select("a[href*=$desen]").filter { it.selectFirst("img") != null || it.parent()?.selectFirst("img") != null }
    println("   '$desen' içeren görselli bağlantı sayısı: ${linkler.size}")
    linkler.firstOrNull()?.let { a ->
        var e: Element = a
        repeat(3) { e.parent()?.let { p -> if (p.select("a[href*=$desen]").size <= 2) e = p } }
        println("   İLK KART (üst öğe ${e.tagName()}.${e.className()}): " + tek(e.outerHtml()).take(2200))
    }
    return linkler
}

fun bagliam(html: String, kelimeler: List<String>, n: Int = 3) {
    for (k in kelimeler) {
        var i = html.indexOf(k); var say = 0
        while (i >= 0 && say < n) {
            println("   «$k» … " + tek(html.substring(maxOf(0, i - 250), minOf(html.length, i + 450))))
            i = html.indexOf(k, i + k.length); say++
        }
    }
}


val HARIC = setOf("category", "platform", "dizi-kategori", "locale", "film-izle", "dizi-izle", "animes", "kesfet", "takvim", "forum", "uye-girisi", "trend", "koleksiyonlar", "ara", "page", "")
fun icerikMi(u: String): Boolean { if (!u.startsWith(ANA)) return false; val ilk = u.removePrefix(ANA).trim('/').split("/").first().substringBefore("?"); return ilk !in HARIC }

fun kartGoster(doc: Document, etiket: String) {
    val a = doc.select("a[href]").filter { icerikMi(it.attr("abs:href")) && (it.selectFirst("img") != null) }
    println("   [$etiket] içerik kartı: ${a.size} | ilk 6: " + a.take(6).joinToString(" ") { it.attr("abs:href") })
    a.firstOrNull()?.let { x ->
        var e: Element = x
        repeat(4) { e.parent()?.let { p -> if (p.select("a[href]").count { icerikMi(it.attr("abs:href")) } <= 2) e = p } }
        println("   [$etiket] KART HTML (${e.tagName()}): " + tek(e.outerHtml()).take(2500))
    }
}

suspend fun sayfaIncele(url: String, kelimeler: List<String>) {
    val r = runCatching { app.get(url, headers = UA, timeout = 30) }.getOrNull() ?: run { println("HATA $url"); return }
    val d = Jsoup.parse(r.text, r.url)
    println("\n##### $url -> ${r.code} | başlık=${d.title()} | h1=${d.select("h1").text()} | uzunluk=${r.text.length}")
    println("   og:image=${d.selectFirst("meta[property=og:image]")?.attr("content")} | og:type=${d.selectFirst("meta[property=og:type]")?.attr("content")}")
    println("   description=${d.selectFirst("meta[name=description]")?.attr("content")?.take(250)}")
    println("   iframe: " + d.select("iframe").map { it.attr("src") + " | data-src=" + it.attr("data-src") })
    println("   ld+json: " + d.select("script[type=application/ld+json]").map { tek(it.data()).take(1200) })
    val main = d.selectFirst("main") ?: d.body()
    println("   MAIN METİN: " + tek(main.text()).take(1500))
    bagliam(r.text, kelimeler, 3)
    val linkler = d.select("a[href]").map { it.attr("abs:href") }.filter { it.contains("/bolum/") || it.contains("sezon") }.distinct()
    println("   bölüm/sezon bağlantıları (${linkler.size}): " + linkler.take(12).joinToString(" "))
    val scriptler = d.select("script[src]").map { it.attr("abs:src") }
    println("   script src: " + scriptler.take(20))
    val butonlar = d.select("[data-id], [data-src], [data-url], [data-embed], [data-video], [data-player], [data-source], [data-link], [x-data]").take(15).map { tek(it.outerHtml()).take(400) }
    println("   data-* öğeleri: " + butonlar.joinToString("\n      "))
}


suspend fun oynatici(url: String) {
    val r = app.get(url, headers = UA, timeout = 30)
    val d = Jsoup.parse(r.text, r.url)
    println("\n##### OYNATICI $url -> ${r.code}")
    val kutu = d.selectFirst("[data-player-shell]")
    println("   KUTU HTML: " + (kutu?.outerHtml()?.let { tek(it).replace(Regex("<svg[\\s\\S]*?</svg>"), "<svg/>") }?.take(7000) ?: "yok"))
    println("   template: " + d.select("template").map { tek(it.outerHtml()).take(800) })
    val html = r.text
    for (k in listOf("pilavyerplay", "data-embed", "data-src", "data-source", "data-url", "data-iframe", "playerSources", "sources", "embed_url", "embedUrl", "/izle/", "kaynak", "source-", "data-tab")) {
        var i = html.indexOf(k); var n = 0
        while (i >= 0 && n < 4) { println("   «$k» … " + tek(html.substring(maxOf(0, i - 200), minOf(html.length, i + 400))).replace(Regex("<svg[\\s\\S]*?</svg>"), "<svg/>")); i = html.indexOf(k, i + k.length); n++ }
    }
    // script blokları içinde oynatıcıyla ilgili olanlar
    d.select("script:not([src])").map { it.data() }.filter { it.contains("player", true) && (it.contains("iframe") || it.contains("src")) }.forEach { println("   SCRIPT: " + tek(it).take(3000)) }
}



suspend fun akisTest(sayfa: String) {
    val html = app.get(sayfa, headers = UA, timeout = 30).text
    val slug = Regex("""data-pv="([^"]+)"""").find(html)?.groupValues?.get(1) ?: return println("slug yok $sayfa")
    val base = Regex("""src="(https://[^"]+)/assets/js/core\.js""").find(html)?.groupValues?.get(1) ?: return println("base yok")
    val emb = "$base/assets/js/s.php?s=$slug"
    val t = app.get(emb, headers = UA + mapOf("Referer" to "$ANA/"), timeout = 30).text
    val js = Regex("""window\.__PLAYER__\s*=\s*(\{.*?\});\s*</script>""", RegexOption.DOT_MATCHES_ALL).find(t)?.groupValues?.get(1) ?: return println("PLAYER yok")
    val o = org.json.JSONObject(js)
    val stream = o.getString("stream")
    println("\n##### AKIŞ $sayfa\n   stream=$stream")
    val denemeler = listOf(
        "referer=embed+origin" to mapOf("Referer" to emb, "Origin" to base),
        "referer=embed" to mapOf("Referer" to emb),
        "referer=base/" to mapOf("Referer" to "$base/"),
        "başlıksız" to mapOf<String, String>()
    )
    for ((ad, h) in denemeler) {
        val r = runCatching { app.get(stream, headers = UA + h, timeout = 30) }.getOrNull()
        println("   [$ad] -> ${r?.code} ctype=${r?.headers?.get("content-type")} uzunluk=${r?.text?.length} son=${r?.url}")
        if (ad == "referer=embed+origin" && r != null) {
            println("   İÇERİK: " + r.text.take(1500))
            val satirlar = r.text.lines().filter { it.isNotBlank() && !it.startsWith("#") }
            val ilk = satirlar.firstOrNull()?.let { if (it.startsWith("http")) it else java.net.URI(r.url).resolve(it).toString() }
            if (ilk != null) {
                for ((ad2, h2) in listOf("embed+origin" to mapOf("Referer" to emb, "Origin" to base), "başlıksız" to mapOf<String, String>())) {
                    val r2 = runCatching { app.get(ilk, headers = UA + h2, timeout = 30) }.getOrNull()
                    println("   ALT [$ad2] $ilk -> ${r2?.code} ctype=${r2?.headers?.get("content-type")} uzunluk=${r2?.text?.length}")
                    if (ad2 == "embed+origin" && r2 != null && (r2.headers["content-type"] ?: "").contains("mpegurl", true)) {
                        println("   ALT İÇERİK: " + r2.text.take(800))
                        val seg = r2.text.lines().firstOrNull { it.isNotBlank() && !it.startsWith("#") }?.let { if (it.startsWith("http")) it else java.net.URI(r2.url).resolve(it).toString() }
                        if (seg != null) for ((ad3, h3) in listOf("embed+origin" to mapOf("Referer" to emb, "Origin" to base), "başlıksız" to mapOf<String, String>())) {
                            val r3 = runCatching { app.get(seg, headers = UA + h3, timeout = 30) }.getOrNull()
                            println("   SEGMENT [$ad3] $seg -> ${r3?.code} ctype=${r3?.headers?.get("content-type")} boyut=${r3?.body?.bytes()?.size}")
                        }
                    }
                }
            }
        }
    }
    val subs = o.optJSONArray("subs")
    if (subs != null && subs.length() > 0) {
        val s0 = subs.getJSONObject(0).getString("src")
        val rs = runCatching { app.get(s0, headers = UA + mapOf("Referer" to emb), timeout = 30) }.getOrNull()
        println("   ALTYAZI $s0 -> ${rs?.code} ctype=${rs?.headers?.get("content-type")} | ${rs?.text?.take(200)?.replace("\n", " ")}")
        val rs2 = runCatching { app.get(s0, headers = UA, timeout = 30) }.getOrNull()
        println("   ALTYAZI başlıksız -> ${rs2?.code}")
    }
}

fun main(args: Array<String>) = runBlocking {
    println("=== pilavyer akış testi ===")
    akisTest("$ANA/wonder-woman/")
    akisTest("$ANA/bolum/reacher-1-sezon-1-bolum/")
    val pj = runCatching { app.get("https://play2.pilavyerplay.top/assets/js/player.js?v=1785510715", headers = UA + mapOf("Referer" to "https://play2.pilavyerplay.top/"), timeout = 30).text }.getOrNull() ?: ""
    println("\n##### player.js uzunluk=${pj.length}")
    for (k in listOf("cdnProbe", "tokenUrl", ".stream", "stream", "loadSource", "beatUrl", "accessCode")) {
        var i = pj.indexOf(k); var n = 0
        while (i >= 0 && n < 3) { println("   «$k» … " + tek(pj.substring(maxOf(0, i - 200), minOf(pj.length, i + 350)))); i = pj.indexOf(k, i + k.length); n++ }
    }
    println("\n=== BİTTİ ===")
}
