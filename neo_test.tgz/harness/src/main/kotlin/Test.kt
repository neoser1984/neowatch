import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.jsoup.Jsoup

fun main(args: Array<String>) = runBlocking {
    val api = SuperFilmGeldi()
    println("=== SuperFilmGeldi (superfilmizle.org) eklenti testi — kategori: ${api.mainPage.size} ===")
    for ((i, k) in api.mainPage.withIndex()) {
        val r = runCatching { withTimeout(60_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        var s2 = ""
        if (i < 4 || i % 9 == 0) {
            val r2 = runCatching { withTimeout(60_000) { api.getMainPage(2, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
            val l2 = r2.getOrNull()?.items?.flatMap { it.list }.orEmpty()
            s2 = " | s2=${l2.size} ilk=${l2.firstOrNull()?.name} ayni=${l2.firstOrNull()?.url == l.firstOrNull()?.url}"
        }
        println("KAT ${k.name} -> ${l.size} hasNext=${r.getOrNull()?.hasNext} ${r.exceptionOrNull()?.let { "HATA $it" } ?: ""} | ${l.take(2).joinToString { "${it.name} [${it.type}] ${it.url}" }}$s2")
    }
    val ilk = api.getMainPage(1, MainPageRequest("Filmler", api.mainPage.first().data, false)).items.first().list.first()
    println("ÖRNEK KART: ${ilk.name} | ${ilk.url} | poster=${ilk.posterUrl} | yıl=${(ilk as? MovieSearchResponse)?.year} | puan=${ilk.score}")

    for (q in listOf("matrix", "reacher", "naruto")) {
        val r = runCatching { api.search(q) }
        println("ARAMA $q -> ${r.getOrNull()?.size} ${r.exceptionOrNull() ?: ""} | ${r.getOrNull()?.take(4)?.joinToString { "${it.name} [${it.type}] ${it.url}" }}")
    }

    for (u in listOf("https://superfilmizle.org/wonder-woman/", "https://superfilmizle.org/dizi/reacher/", "https://superfilmizle.org/anime/cyberpunk-edgerunners/")) {
        val r = runCatching { withTimeout(120_000) { api.load(u) } }
        val y = r.getOrNull()
        println("\nLOAD $u -> ${y?.name} tür=${y?.type} yıl=${y?.year} puan=${y?.score} süre=${y?.duration} etiket=${y?.tags} poster=${y?.posterUrl} fragman=${y?.trailers?.map { it.extractorUrl }} öneri=${y?.recommendations?.size} oyuncu=${y?.actors?.size} ${r.exceptionOrNull() ?: ""}")
        println("   konu: ${y?.plot?.take(150)}")
        val veri = when (y) {
            is MovieLoadResponse -> y.dataUrl
            is TvSeriesLoadResponse -> {
                println("   bölüm sayısı=${y.episodes.size} sezonlar=${y.episodes.map { it.season }.distinct()} ilk=${y.episodes.take(2).map { "S${it.season}E${it.episode} ${it.name} ${it.data}" }} son=${y.episodes.lastOrNull()?.let { "S${it.season}E${it.episode} ${it.data}" }}")
                y.episodes.firstOrNull()?.data
            }
            else -> null
        } ?: continue
        val linkler = mutableListOf<ExtractorLink>(); val alt = mutableListOf<SubtitleFile>()
        val ok = runCatching { withTimeout(90_000) { api.loadLinks(veri, false, { alt.add(it) }, { linkler.add(it) }) } }
        println("   LINKS ok=${ok.getOrNull()} ${ok.exceptionOrNull() ?: ""} altyazı=${alt.map { it.lang }}")
        for (l in linkler) {
            val h = l.headers + mapOf("Referer" to l.referer)
            val m = runCatching { app.get(l.url, headers = h, timeout = 30) }.getOrNull()
            println("   - ${l.name} ${l.type} -> ${m?.code} ${m?.headers?.get("content-type")} | ${l.url.take(110)}")
            val alt1 = m?.text?.lines()?.firstOrNull { it.isNotBlank() && !it.startsWith("#") }
            if (alt1 != null) {
                val altUrl = if (alt1.startsWith("http")) alt1 else java.net.URI(m.url).resolve(alt1).toString()
                val m2 = runCatching { app.get(altUrl, headers = h, timeout = 30) }.getOrNull()
                val seg = m2?.text?.lines()?.firstOrNull { it.isNotBlank() && !it.startsWith("#") }
                println("     alt liste -> ${m2?.code} ${m2?.headers?.get("content-type")} | ilk satır: ${seg?.take(90)}")
            }
        }
    }

    // ana sayfadaki tüm dizi-kategori ve platform bağlantıları (başvuru için)
    val doc = Jsoup.parse(app.get("https://superfilmizle.org/").text, "https://superfilmizle.org/")
    println("\nDİZİ KATEGORİLERİ: " + doc.select("a[href*=/dizi-kategori/]").map { it.attr("href").substringAfter("dizi-kategori/").trim('/') + "=" + it.text() }.distinct())
    println("PLATFORMLAR: " + doc.select("a[href*=/platform/]").map { it.attr("href").substringAfter("platform/").trim('/') }.distinct())
    println("\n=== BİTTİ ===")
}
