import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.jsoup.Jsoup
import com.neowatch.jetfilmizle.VideoPark
import com.neowatch.jetfilmizle.PlayerX

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

val EKLENTILER = listOf("AnimeciX", "BelgeselX", "CanliTV", "CizgiMax", "DiziBal", "DiziBox", "DiziKorea", "DiziMom", "DiziPal", "DiziPalGuncel", "DiziPalOrjinal", "DiziYou", "Dizilla", "FilmMakinesi", "FilmModu", "FullHDFilm", "FullHDFilmizlesene", "HDFilmCehennemi", "InatBox", "JetFilmizle", "KoreanTurk", "KultFilmler", "NetflixMirror", "RareFilmm", "RecTV", "SelcukFlix", "SetFilmIzle", "SezonlukDizi", "SinemaCX", "SuperFilmGeldi", "TurkAnime", "UgurFilm", "WebDramaTurkey", "WebteIzle", "YouTube")

// Kodu test düzeneğinde derlenmeyenler ve PR #4'teki aday adresler: yalnızca ham kontrol
val HAM = listOf(
    "https://watch2movies.net",
    "https://dizipal2145.com", "https://dizipalorjinal18.com", "https://superfilmizle.click"
)

fun hata(t: Throwable?) = t?.let { "HATA ${it.javaClass.simpleName}: ${it.message?.take(90)}" } ?: ""

suspend fun hamKontrol(u: String): String {
    val r1 = runCatching { app.get(u, headers = UA, allowRedirects = false, timeout = 20) }
    val c1 = r1.getOrNull() ?: return "ham=YOK ${hata(r1.exceptionOrNull())}"
    val sb = StringBuilder("ham=${c1.code} loc=${c1.headers["location"] ?: "-"}")
    var metin = c1.text
    if (c1.code in 300..399) {
        val r2 = runCatching { app.get(u, headers = UA, timeout = 25) }
        val c2 = r2.getOrNull()
        sb.append(" | son=${c2?.url} ${c2?.code} ${hata(r2.exceptionOrNull())}")
        metin = c2?.text ?: ""
    }
    val d = Jsoup.parse(metin)
    sb.append(" | başlık='${d.title().take(60)}' uzunluk=${metin.length} canonical=${d.selectFirst("link[rel=canonical]")?.attr("href") ?: "-"}")
    return sb.toString()
}

suspend fun eklentiTest(ad: String): String {
    val sb = StringBuilder()
    val api = runCatching { Class.forName("com.neowatch.${ad.lowercase()}.$ad").getDeclaredConstructor().newInstance() as MainAPI }
        .getOrElse { return "### $ad: OLUŞTURULAMADI ${hata(it)}" }
    sb.appendLine("### $ad (${api.mainUrl}) kategori=${api.mainPage.size}")
    if (api.mainUrl.startsWith("http")) sb.appendLine("  " + hamKontrol(api.mainUrl))
    var ilk: SearchResponse? = null
    for (k in api.mainPage.take(2)) {
        val r = runCatching { withTimeout(60_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        sb.appendLine("  KAT ${k.name} -> ${l.size} ${hata(r.exceptionOrNull())} | ${l.take(2).joinToString { it.name.take(40) }}")
        if (ilk == null) ilk = l.firstOrNull { it.type != TvType.Live } ?: l.firstOrNull()
    }
    val hedef = ilk ?: return sb.toString()
    val y = runCatching { withTimeout(60_000) { api.load(hedef.url) } }
    val yy = y.getOrNull()
    val veri = when (yy) {
        is TvSeriesLoadResponse -> yy.episodes.firstOrNull()?.data
        is AnimeLoadResponse    -> yy.episodes.values.flatten().firstOrNull()?.data
        is MovieLoadResponse    -> yy.dataUrl
        is LiveStreamLoadResponse -> yy.dataUrl
        else -> null
    }
    val bolum = when (yy) { is TvSeriesLoadResponse -> yy.episodes.size; is AnimeLoadResponse -> yy.episodes.values.sumOf { it.size }; else -> -1 }
    sb.appendLine("  LOAD ${hedef.name.take(40)} -> ${yy?.name?.take(40)} ${yy?.type} bölüm=$bolum ${hata(y.exceptionOrNull())}")
    if (veri != null) {
        val links = mutableListOf<ExtractorLink>()
        val ok = runCatching { withTimeout(70_000) { api.loadLinks(veri, false, {}, { links.add(it) }) } }
        sb.appendLine("  LINKS ok=${ok.getOrNull()} adet=${links.size} ${hata(ok.exceptionOrNull())} | ${links.take(3).joinToString { it.name.take(25) + " " + it.url.substringAfter("://").substringBefore("/") }}")
    }
    return sb.toString()
}

suspend fun yapiDok(u: String, ref: String? = null, sinir: Int = 22000, post: Map<String, String>? = null) {
    val r = runCatching {
        if (post != null) app.post(u, headers = UA + mapOf("X-Requested-With" to "XMLHttpRequest"), referer = ref, data = post, timeout = 25)
        else app.get(u, headers = UA, referer = ref, timeout = 25)
    }
    val c = r.getOrNull()
    println("\n######## $u -> ${c?.code} ${hata(r.exceptionOrNull())} son=${c?.url}")
    if (c == null) return
    val d = Jsoup.parse(c.text, u)
    println("TITLE: ${d.title()}")
    d.select("script[type=application/ld+json]").forEach { println("LDJSON: " + it.data().replace(Regex("\\s+"), " ").take(1500)) }
    d.select("script:not([src])").forEach { sc -> val t = sc.data(); if (Regex("iframe|player|source|embed|ajax|fetch\\(|\\.m3u8|episode|bolum", RegexOption.IGNORE_CASE).containsMatchIn(t) && t.length < 6000) println("SCRIPT: " + t.replace(Regex("\\s+"), " ").take(2500)) }
    d.select("script,style,svg,noscript,link,meta,head").remove()
    d.select("*").forEach { e -> e.attributes().asList().filter { it.key == "style" || it.key.startsWith("aria-") || it.key == "srcset" || it.key == "sizes" }.forEach { e.removeAttr(it.key) } }
    val govde = d.body()?.html()?.replace(Regex("\\s+"), " ")?.replace(Regex("> <"), "><") ?: ""
    println("BODY(${govde.length}): " + govde.take(sinir))
}

suspend fun aramaTest(ad: String, sorgu: String): String {
    val api = runCatching { Class.forName("com.neowatch.${ad.lowercase()}.$ad").getDeclaredConstructor().newInstance() as MainAPI }.getOrElse { return "ARAMA $ad: OLUŞTURULAMADI" }
    val r = runCatching { withTimeout(60_000) { api.search(sorgu) } }
    val l = r.getOrNull().orEmpty()
    return "  ARAMA $ad '$sorgu' -> ${l.size} ${hata(r.exceptionOrNull())} | ${l.take(3).joinToString { it.name.take(30) + " " + it.url.substringAfter("://").take(60) }}"
}

suspend fun hamDok(u: String, ref: String?, sinir: Int = 12000) {
    val r = runCatching { app.get(u, headers = UA + mapOf("Sec-Fetch-Dest" to "iframe"), referer = ref, timeout = 25) }
    val c = r.getOrNull()
    println("\n######## HAM $u (ref=$ref) -> ${c?.code} ${hata(r.exceptionOrNull())} son=${c?.url}")
    if (c == null) return
    val t = c.text
    println("UZUNLUK ${t.length}")
    println(t.replace(Regex("\\s+"), " ").take(sinir))
}

suspend fun scriptDok(u: String, ref: String?, sinir: Int = 40000) {
    val r = runCatching { app.get(u, headers = UA + mapOf("Sec-Fetch-Dest" to "iframe"), referer = ref, timeout = 25) }
    val c = r.getOrNull()
    println("\n######## SCRIPT $u (ref=$ref) -> ${c?.code} ${hata(r.exceptionOrNull())} son=${c?.url}")
    if (c == null) return
    val d = Jsoup.parse(c.text, u)
    println("SRCS: " + d.select("script[src]").joinToString(" ") { it.attr("abs:src") })
    println("IFRAMES: " + d.select("iframe").joinToString(" ") { it.attr("abs:src") })
    val sb = StringBuilder()
    d.select("script:not([src])").forEach { sb.append("\n<<SC>> ").append(it.data().replace(Regex("\\s+"), " ")) }
    println(sb.toString().take(sinir))
    d.select("script,style,svg,noscript,link,meta,head").remove()
    println("BODY: " + (d.body()?.html()?.replace(Regex("\\s+"), " ") ?: "").take(3000))
}

suspend fun extTest(ad: String, blok: suspend ((com.lagradost.cloudstream3.utils.ExtractorLink) -> Unit, (com.lagradost.cloudstream3.SubtitleFile) -> Unit) -> Unit) {
    val links = mutableListOf<com.lagradost.cloudstream3.utils.ExtractorLink>()
    val subs  = mutableListOf<String>()
    val r = runCatching { withTimeout(60_000) { blok({ links.add(it) }, { subs.add(it.lang) }) } }
    println("EXT $ad -> ${hata(r.exceptionOrNull())} links=${links.size} subs=$subs")
    for (l in links.take(4)) {
        val h = runCatching { app.get(l.url, referer = l.referer, headers = l.headers + mapOf("Range" to "bytes=0-300"), timeout = 20) }.getOrNull()
        val bas = runCatching { h?.body?.byteStream()?.use { st -> String(st.readNBytes(80)) } }.getOrNull()
        println("     ${l.name} ${l.type} ${l.url.take(120)} -> ${h?.code} ${h?.headers?.get("content-type")} ${bas?.replace("\n", " ")}")
    }
}

suspend fun stfDok() {
    val ana = "https://www.setfilmizle.ltd"
    val liste = runCatching { app.get("$ana/", headers = UA, timeout = 25).document }.getOrNull() ?: return println("STF ana sayfa yok")
    val film = liste.select("a[href]").map { it.attr("abs:href") }.firstOrNull { Regex("""/film/[a-z0-9-]+/?$""").containsMatchIn(it) } ?: return println("STF film yok")
    val metin = app.get(film, headers = UA, referer = "$ana/", timeout = 25).text
    val nonce = Regex("""video\s*:\s*"([^"]+)"""").find(metin)?.groupValues?.get(1) ?: return println("STF nonce yok")
    val pid = Jsoup.parse(metin).selectFirst("#stfPlayer")?.attr("data-post-id") ?: return println("STF pid yok")
    suspend fun kopru(): String? {
        val govde = okhttp3.MultipartBody.Builder().setType(okhttp3.MultipartBody.FORM)
            .addFormDataPart("action", "get_video_url").addFormDataPart("nonce", nonce)
            .addFormDataPart("post_id", pid).addFormDataPart("player_name", "SetPlay").addFormDataPart("part_key", "").build()
        val y = app.post("$ana/wp-admin/admin-ajax.php", requestBody = govde, referer = film, headers = UA + mapOf("Origin" to ana)).text
        println("STF ajax » ${y.take(300)}")
        return Regex(""""url"\s*:\s*"([^"]+)"""").find(y)?.groupValues?.get(1)?.replace("\\/", "/")
    }
    kopru()?.let { hamDok(it + "&nb2=1", "$ana/", 7000) }
    kopru()?.let { hamDok(it, "$ana/", 7000) }
}

fun npTest() {
    val gn = "Ab3dEf9hIj2K"
    val sayfa = "<script>\nwindow.NP_GATE=function(_vv,_uau){var _yclg=String.fromCharCode(68,70,78,75,87,118,56,85,90,51);for(var _ol=0;_ol<1e8;_ol++){var _mpq=_ol.toString(36);if((_uau(_mpq+'|'+_yclg+'|'+_vv)[6]&4095)===0)return _mpq;}return \"\";};\nwindow.NP_CONFIG = {}</script>"
    val p = com.neowatch.dizipalguncel.NpKapi.coz(sayfa, gn, 12)
    val h = p?.let { java.security.MessageDigest.getInstance("SHA-256").digest("$it|DFNKWv8UZ3|$gn".toByteArray()) }
    val w = h?.let { ((it[24].toLong() and 0xff) shl 24) or ((it[25].toLong() and 0xff) shl 16) or ((it[26].toLong() and 0xff) shl 8) or (it[27].toLong() and 0xff) }
    println("NPKAPI ozel p=$p dogru=${w != null && (w and 4095L) == 0L}")
    val p2 = com.neowatch.dizipalguncel.NpKapi.coz("yok", gn, 12)
    val h2 = p2?.let { java.security.MessageDigest.getInstance("SHA-256").digest("$gn:$it".toByteArray()) }
    println("NPKAPI yedek p=$p2 dogru=${h2 != null && ((h2[0].toInt() and 0xff) shr 4) == 0 && (h2[1].toInt() and 0xff) == 0}")
}

fun main(args: Array<String>) = runBlocking {
    android.util.Log.sessiz = false
    println("=== Eklenti testleri ===")
    for ((u, ref) in listOf("https://rapidvid.org/vx/v1x43addc62" to "https://www.fullhdfilmizlesene.now/")) {
        val r = runCatching { app.get(u, referer = ref, headers = UA + mapOf("Sec-Fetch-Dest" to "iframe"), timeout = 25) }
        val c = r.getOrNull()
        val t = c?.text.orEmpty()
        println("RAPID $u -> ${c?.code} ${hata(r.exceptionOrNull())} başlık='${Jsoup.parse(t).title()}' uzunluk=${t.length} _p8=${t.contains("window._p8")} cf=${t.contains("cf-chl") || t.contains("Attention Required")}")
        println("RAPID BAŞ: " + t.replace(Regex("\\s+"), " ").take(600))
    }
    val bys = "https://bysejikuar.com"
    for (kod in listOf("p3hbgelju7ef", "6kml1ss6864e")) {
        val d = runCatching { app.get("$bys/api/videos/$kod/embed/details", referer = "https://sezonlukdizi.cc/", headers = mapOf("Accept" to "application/json", "x-embed-parent" to "https://sezonlukdizi.cc/"), timeout = 25) }
        println("BYSE details $kod -> ${d.getOrNull()?.code} ${hata(d.exceptionOrNull())} ${d.getOrNull()?.text?.take(400)}")
        val ef = Regex(""""embed_frame_url"\s*:\s*"([^"]+)"""").find(d.getOrNull()?.text.orEmpty())?.groupValues?.get(1)?.replace("\\/", "/")
        if (ef != null) {
            val b = Regex("""^(https?://[^/]+)""").find(ef)!!.groupValues[1]
            val k = ef.substringBefore("?").trimEnd('/').substringAfterLast('/')
            val p = runCatching { app.get("$b/api/videos/$k/embed/playback", referer = ef, headers = mapOf("Accept" to "*/*", "x-embed-parent" to "https://sezonlukdizi.cc/"), timeout = 25) }
            println("BYSE playback $ef -> ${p.getOrNull()?.code} ${hata(p.exceptionOrNull())} ${p.getOrNull()?.text?.take(500)}")
        }
    }
    extTest("ByseNeo") { cb, sb -> com.neowatch.sezonlukdizi.ByseNeo().getUrl("https://bysejikuar.com/e/6kml1ss6864e", "https://sezonlukdizi.cc/", sb, cb) }
    val lr = runCatching { app.get("https://luciferplays.com/embed/8vsm73gdqh0a", referer = "https://superfilmizle.icu/", headers = UA + mapOf("Sec-Fetch-Dest" to "iframe"), timeout = 60) }
    println("LUCIFER -> ${lr.getOrNull()?.code} ${hata(lr.exceptionOrNull())} uzunluk=${lr.getOrNull()?.text?.length}")
    if (lr.getOrNull() != null) scriptDok("https://luciferplays.com/embed/8vsm73gdqh0a", "https://superfilmizle.icu/", 25000)
    println("\n=== BİTTİ ===")
}
