import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import com.neowatch.*
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.jsoup.Jsoup

val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

suspend fun dene(api: MainAPI, kategoriSayisi: Int = 4, arama: String? = null) {
    println("\n==================== ${api.name} (${api.mainUrl}) — kategori ${api.mainPage.size} ====================")
    var ilk: SearchResponse? = null
    for (k in api.mainPage.take(kategoriSayisi)) {
        val r = runCatching { withTimeout(90_000) { api.getMainPage(1, MainPageRequest(k.name, k.data, k.horizontalImages)) } }
        val l = r.getOrNull()?.items?.flatMap { it.list }.orEmpty()
        println("KAT ${k.name} -> ${l.size} hasNext=${r.getOrNull()?.hasNext} ${r.exceptionOrNull() ?: ""} | ${l.take(2).joinToString { "${it.name} ${it.url}" }}")
        if (ilk == null) ilk = l.firstOrNull { it.type != TvType.Movie } ?: l.firstOrNull()
    }
    if (arama != null) {
        val s = runCatching { api.search(arama) }
        println("ARAMA $arama -> ${s.getOrNull()?.size} ${s.exceptionOrNull() ?: ""} | ${s.getOrNull()?.take(3)?.joinToString { "${it.name} ${it.url}" }}")
    }
    val hedef = ilk ?: return
    val y = runCatching { withTimeout(120_000) { api.load(hedef.url) } }
    val yy = y.getOrNull()
    println("LOAD ${hedef.url} -> ${yy?.name} ${yy?.type} yıl=${yy?.year} poster=${yy?.posterUrl?.take(80)} ${y.exceptionOrNull() ?: ""}")
    val veri = when (yy) { is TvSeriesLoadResponse -> { println("   bölüm=${yy.episodes.size} ilk=${yy.episodes.firstOrNull()?.data}"); yy.episodes.firstOrNull()?.data }; is MovieLoadResponse -> yy.dataUrl; else -> null } ?: return
    val links = mutableListOf<ExtractorLink>(); val subs = mutableListOf<SubtitleFile>()
    val ok = runCatching { withTimeout(120_000) { api.loadLinks(veri, false, { subs.add(it) }, { links.add(it) }) } }
    println("   LINKS ok=${ok.getOrNull()} ${ok.exceptionOrNull() ?: ""} altyazı=${subs.size}")
    links.forEach { l -> val m = runCatching { app.get(l.url, headers = l.headers + mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} ${l.type} -> ${m?.code} ${m?.headers?.get("content-type")} | ${l.url.take(100)}") }
}

suspend fun linkleriDene(api: MainAPI, veri: String) {
    val links = mutableListOf<ExtractorLink>(); val subs = mutableListOf<SubtitleFile>()
    val ok = runCatching { withTimeout(120_000) { api.loadLinks(veri, false, { subs.add(it) }, { links.add(it) }) } }
    println("   LINKS ok=${ok.getOrNull()} ${ok.exceptionOrNull() ?: ""} adet=${links.size} altyazı=${subs.size}")
    links.take(6).forEach { l -> val m = runCatching { app.get(l.url, headers = l.headers + mapOf("Referer" to l.referer), timeout = 30) }.getOrNull(); println("   - ${l.name} ${l.type} -> ${m?.code} ${m?.headers?.get("content-type")} | ${l.url.take(140)}") }
}

fun main(args: Array<String>) = runBlocking {
    println("=== Derleme + PowerShell betik testi ===")
    // PowerShell betiği: sözdizimi ve C# derlemesi (InatBox alanları runner'a 403 döner, beklenen)
    runCatching {
        val p = ProcessBuilder("pwsh", "-NoProfile", "-NonInteractive", "-File", "inat_link_test.ps1").redirectErrorStream(true).start()
        p.outputStream.close()
        val bitti = p.waitFor(150, java.util.concurrent.TimeUnit.SECONDS)
        val cikti = p.inputStream.bufferedReader().readText()
        println("pwsh bitti=$bitti kod=${if (bitti) p.exitValue() else -1}\n" + cikti.take(6000))
        if (!bitti) p.destroyForcibly()
    }.onFailure { println("pwsh hata $it") }

    // DiziPal: dizi yükleme + doğrulama uyarısı
    val dp = DiziPal()
    val y = runCatching { dp.load("https://dizipal2142.com/bolum/the-new-stanford-prison-experiment-1-sezon-6-bolum") }
    println("DiziPal LOAD -> ${y.getOrNull()?.name} ${y.exceptionOrNull() ?: ""}")
    linkleriDene(dp, "https://dizipal2142.com/bolum/the-new-stanford-prison-experiment-1-sezon-6-bolum")

    // DiziPalGuncel: derlendi mi + runner erişimi
    val g = DiziPalGuncel()
    val k = runCatching { g.getMainPage(1, MainPageRequest(g.mainPage[1].name, g.mainPage[1].data, false)) }
    println("DiziPalGuncel KAT ${g.mainPage[1].name} -> ${k.getOrNull()?.items?.flatMap { it.list }?.size} ${k.exceptionOrNull() ?: ""} (runner Cloudflare engeli beklenir)")
    println("\n=== BİTTİ ===")
}
