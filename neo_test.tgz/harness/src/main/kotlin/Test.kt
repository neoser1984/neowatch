import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.*
import kotlinx.coroutines.runBlocking
import org.jsoup.Jsoup

val ANA = "https://superfilmizle.org"
val UA = mapOf("User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0 Safari/537.36")

suspend fun bak(u: String) {
    val r = runCatching { app.get(u, headers = UA, timeout = 30) }.getOrNull() ?: return println("HATA $u")
    val d = Jsoup.parse(r.text, r.url)
    val kart = d.select("a.group[href]").filter { it.selectFirst("h3") != null }.map { it.attr("abs:href") }.distinct()
    val sayfa = d.select("a[href]").map { it.attr("abs:href") }.filter { Regex("""page[/=]\d""").containsMatchIn(it) }.distinct()
    val next = d.select("link[rel=next], a[rel=next]").map { it.attr("abs:href") }
    println("$u -> ${r.code} son=${r.url} kart=${kart.size} ilk=${kart.take(2)} | sayfa bağlantıları=${sayfa.take(8)} | rel=next $next")
}

fun main(args: Array<String>) = runBlocking {
    println("=== sayfalama ===")
    for (u in listOf(
        "$ANA/animes/", "$ANA/animes/page/2/", "$ANA/animes/?page=2", "$ANA/animes/?sayfa=2",
        "$ANA/platform/netflix/", "$ANA/platform/netflix/page/2/", "$ANA/platform/netflix/?page=2",
        "$ANA/film-izle/?platform=netflix", "$ANA/film-izle/page/2/?platform=netflix", "$ANA/film-izle/?platform=netflix&page=2",
        "$ANA/dizi-izle/?platform=netflix", "$ANA/dizi-izle/page/2/?platform=netflix",
        "$ANA/film-izle/?sirala=yeni", "$ANA/film-izle/page/2/?sirala=yeni",
        "$ANA/category/aksiyon-filmleri/page/2/", "$ANA/dizi-kategori/kore-dizileri/", "$ANA/dizi-kategori/gerilim-dizileri/", "$ANA/dizi-kategori/korku-dizileri/",
        "$ANA/dizi-kategori/romantik-dizileri/", "$ANA/dizi-kategori/yerli-dizileri/", "$ANA/dizi-kategori/savas-dizileri/", "$ANA/platform/blutv/", "$ANA/platform/tod/", "$ANA/platform/puhutv/"
    )) bak(u)
    println("\n=== BİTTİ ===")
}
