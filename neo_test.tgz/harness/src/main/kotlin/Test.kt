import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

fun main(args: Array<String>) = runBlocking {
    println("=== JitPack erişim testi (runner) ===")
    val c = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build()
    val j = "https://jitpack.io/com/github/recloudstream/gradle"
    val adresler = listOf(
        "$j/master-SNAPSHOT/maven-metadata.xml",
        "$j/master-SNAPSHOT/gradle-master-32895aedb6-1.pom",
        "$j/master-SNAPSHOT/gradle-master-SNAPSHOT.pom",
        "$j/master-32895aedb6-1/gradle-master-32895aedb6-1.pom",
        "$j/master-32895aedb6-1/gradle-master-32895aedb6-1.jar",
        "$j/gradle/master-SNAPSHOT/maven-metadata.xml",
        "$j/gradle/master-SNAPSHOT/gradle-master-32895aedb6-1.pom",
        "$j/gradle/master-SNAPSHOT/gradle-master-32895aedb6-1.jar",
        "$j/gradle/master-32895aedb6-1/gradle-master-32895aedb6-1.pom",
        "$j/gradle/master-32895aedb6-1/gradle-master-32895aedb6-1.jar",
        "$j/32895aedb6/gradle-32895aedb6.pom",
        "$j/gradle/32895aedb6/gradle-32895aedb6.pom",
        "$j/master-32895aedb6-1/build.log",
        "https://jitpack.io/com/github/recloudstream/cloudstream/library-jvm/4.8.0/library-jvm-4.8.0.pom",
        "https://jitpack.io/com/github/Blatzar/NiceHttp/0.4.11/NiceHttp-0.4.11.pom",
        "https://jitpack.io/api/builds/com.github.recloudstream/gradle/latest",
    )
    for (u in adresler) {
        for (deneme in 1..2) {
            val r = runCatching { c.newCall(Request.Builder().url(u).header("User-Agent", "Gradle/8.12").build()).execute() }
            val y = r.getOrNull()
            val govde = y?.body?.string() ?: ""
            println("[$deneme] ${y?.code} uzunluk=${govde.length} cf=${y?.header("cf-cache-status")} age=${y?.header("age")} server=${y?.header("server")} | ${u.removePrefix("https://jitpack.io")} ${r.exceptionOrNull() ?: ""}")
            if (u.endsWith(".pom") && govde.isNotEmpty()) println("      " + govde.replace(Regex("\\s+"), " ").take(600))
            if (u.endsWith("build.log")) println("      SON: " + govde.takeLast(1500).replace(Regex("\\s+"), " "))
            if (u.contains("/api/")) println("      " + govde.take(300))
            y?.close()
            Thread.sleep(1500)
        }
    }
    println("\n=== BİTTİ ===")
}
