# ============================================================================
#  InatBox baglanti testi (NeoWatch) - 24 Ekim 2026
#  Eklentinin yaptigini birebir yapar: kategori dizinini, birkac film / dizi /
#  kanal kaydini ister ve video adresini eklentiyle ayni yoldan cozmeye calisir.
#  Sonuc: "inat_link_sonuc.txt" ve "inat_link_*.json" (bu klasore yazilir).
#  Istekler uygulamadaki gibi imzali ve araliklidir.
# ============================================================================
$ErrorActionPreference = 'Continue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]'Tls13' } catch {}

$kaynak = @"
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;

public static class InatT
{
    const string HMK = "x7kkk0qmqz63kj68tla5i7u26192v7zqnnddhjgm";
    public const string VARS = "ywevqtjrurkwtqgz";
    public static long ZamanFarki = 0;
    static readonly DateTime Epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);

    static string Hex(byte[] b) { StringBuilder sb = new StringBuilder(); foreach (byte x in b) sb.Append(x.ToString("x2")); return sb.ToString(); }

    static string Rastgele(int n)
    {
        const string h = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        byte[] b = new byte[n];
        using (RandomNumberGenerator r = RandomNumberGenerator.Create()) r.GetBytes(b);
        StringBuilder sb = new StringBuilder();
        foreach (byte x in b) sb.Append(h[x % h.Length]);
        return sb.ToString();
    }

    static string Sha(string s) { using (SHA256 h = SHA256.Create()) return Hex(h.ComputeHash(Encoding.UTF8.GetBytes(s))); }

    static string Imza(string m) { using (HMACSHA256 h = new HMACSHA256(Encoding.UTF8.GetBytes(HMK))) return Hex(h.ComputeHash(Encoding.UTF8.GetBytes(m))); }

    static string Zaman() { return (((long)(DateTime.UtcNow - Epoch).TotalSeconds) + ZamanFarki).ToString(); }

    static string Nonce() { byte[] nb = new byte[16]; using (RandomNumberGenerator r = RandomNumberGenerator.Create()) r.GetBytes(nb); return Hex(nb); }

    static void Baslik(HttpWebRequest req, string a, string v)
    {
        try
        {
            if (a.Equals("User-Agent", StringComparison.OrdinalIgnoreCase)) req.UserAgent = v;
            else if (a.Equals("Referer", StringComparison.OrdinalIgnoreCase)) req.Referer = v;
            else if (a.Equals("Accept", StringComparison.OrdinalIgnoreCase)) req.Accept = v;
            else if (a.Equals("Content-Type", StringComparison.OrdinalIgnoreCase)) req.ContentType = v;
            else req.Headers[a] = v;
        }
        catch (Exception) { }
    }

    static string Oku(HttpWebRequest req, out int kod, out string tip, out string st)
    {
        HttpWebResponse resp;
        try { resp = (HttpWebResponse)req.GetResponse(); }
        catch (WebException e) { resp = e.Response as HttpWebResponse; if (resp == null) { kod = -1; tip = ""; st = ""; return "HATA " + e.Message; } }
        using (resp)
        {
            kod = (int)resp.StatusCode;
            tip = resp.ContentType ?? "";
            st = resp.Headers["x-st"] ?? "";
            using (StreamReader sr = new StreamReader(resp.GetResponseStream(), Encoding.UTF8)) return sr.ReadToEnd();
        }
    }

    // Uygulamanin imzali POST istegi (govde 1=<r>&0=<r>, yanit <r> anahtariyla cozulur)
    public static string Istek(string url, out string anahtar, out int kod)
    {
        anahtar = Rastgele(16);
        string govde = "1=" + anahtar + "&0=" + anahtar;
        string yol = new Uri(url).AbsolutePath;
        string metin = ""; kod = 0;
        for (int deneme = 0; deneme < 2; deneme++)
        {
            string zaman = Zaman(); string nonce = Nonce();
            string imza = Imza("POST\n" + yol + "\n" + zaman + "\n" + nonce + "\n" + Sha(govde));
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = "POST"; req.UserAgent = "speedrestapi"; req.Referer = "https://speedrestapi.com/";
            req.ContentType = "application/x-www-form-urlencoded; charset=UTF-8"; req.Timeout = 20000;
            req.Headers.Add("X-Requested-With", "com.bp.box"); req.Headers.Add("Cache-Control", "no-cache");
            req.Headers.Add("X-Ts", zaman); req.Headers.Add("X-Nc", nonce); req.Headers.Add("X-Sg", imza);
            byte[] gb = Encoding.UTF8.GetBytes(govde); req.ContentLength = gb.Length;
            using (Stream s = req.GetRequestStream()) s.Write(gb, 0, gb.Length);
            string tip, st;
            metin = Oku(req, out kod, out tip, out st);
            long sz;
            if (kod == 403 && long.TryParse(st, out sz) && sz > 0 && deneme == 0) { ZamanFarki = sz - (long)(DateTime.UtcNow - Epoch).TotalSeconds; continue; }
            break;
        }
        return metin;
    }

    // tekli_regex_lb_sh kayitlari icin imzali GET (kaydin basliklariyla)
    public static string ImzaliGet(string url, string[] adlar, string[] degerler, out int kod)
    {
        string yol = new Uri(url).AbsolutePath;
        string metin = ""; kod = 0;
        for (int deneme = 0; deneme < 2; deneme++)
        {
            string zaman = Zaman(); string nonce = Nonce();
            string imza = Imza("GET\n" + yol + "\n" + zaman + "\n" + nonce + "\n" + Sha(""));
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = "GET"; req.Timeout = 20000;
            for (int i = 0; i < adlar.Length; i++) Baslik(req, adlar[i], degerler[i]);
            req.Headers["Cache-Control"] = "no-cache"; req.Headers["X-Ts"] = zaman; req.Headers["X-Nc"] = nonce; req.Headers["X-Sg"] = imza;
            string tip, st;
            metin = Oku(req, out kod, out tip, out st);
            long sz;
            if (kod == 403 && long.TryParse(st, out sz) && sz > 0 && deneme == 0) { ZamanFarki = sz - (long)(DateTime.UtcNow - Epoch).TotalSeconds; continue; }
            break;
        }
        return metin;
    }

    // Duz GET / POST; govdeyi ve durum bilgisini dondurur
    public static string Get(string url, string[] adlar, string[] degerler, string post, out int kod, out string tip)
    {
        try
        {
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
            req.Method = post == null ? "GET" : "POST"; req.Timeout = 20000; req.AllowAutoRedirect = true;
            for (int i = 0; i < adlar.Length; i++) Baslik(req, adlar[i], degerler[i]);
            if (post != null)
            {
                if (string.IsNullOrEmpty(req.ContentType)) req.ContentType = "application/x-www-form-urlencoded";
                byte[] gb = Encoding.UTF8.GetBytes(post); req.ContentLength = gb.Length;
                using (Stream s = req.GetRequestStream()) s.Write(gb, 0, gb.Length);
            }
            string st;
            return Oku(req, out kod, out tip, out st);
        }
        catch (Exception e) { kod = -1; tip = ""; return "HATA " + e.Message; }
    }

    static byte[] AnahtarB(string a)
    {
        byte[] b = Encoding.UTF8.GetBytes(a);
        int n = b.Length;
        int hedef = (n == 16 || n == 24 || n == 32) ? n : (n < 24 ? 16 : (n < 32 ? 24 : 32));
        byte[] r = new byte[hedef];
        Array.Copy(b, r, Math.Min(n, hedef));
        return r;
    }

    static byte[] Ilk16(byte[] b) { byte[] r = new byte[16]; Array.Copy(b, r, Math.Min(16, b.Length)); return r; }

    static bool Makul(string s)
    {
        if (string.IsNullOrEmpty(s)) return false;
        if (s.StartsWith("[") || s.StartsWith("{")) return true;
        if (s.Length < 16) return false;
        foreach (char c in s) if (!(char.IsLetterOrDigit(c) || "+/=:-_\r\n".IndexOf(c) >= 0)) return false;
        return true;
    }

    static string Json(string s)
    {
        s = s.Trim();
        if (!(s.StartsWith("[") || s.StartsWith("{"))) return null;
        int son = Math.Max(s.LastIndexOf(']'), s.LastIndexOf('}'));
        return son > 0 ? s.Substring(0, son + 1) : s;
    }

    static byte[] B64(string s) { try { return Convert.FromBase64String(s); } catch (Exception) { return null; } }

    static string Katman(string veri, string[] anahtarlar)
    {
        int ay = veri.IndexOf(':');
        string sifre = (ay >= 0 ? veri.Substring(0, ay) : veri).Trim();
        string ek = ay >= 0 ? veri.Substring(ay + 1).Trim() : "";
        byte[] sb = B64(sifre); if (sb == null) return null;
        byte[] eb = ek.Length > 0 ? B64(ek) : null;
        List<byte[][]> den = new List<byte[][]>();
        foreach (string a in anahtarlar)
        {
            byte[] ab = AnahtarB(a);
            if (eb != null && eb.Length == 16) den.Add(new byte[][] { ab, eb });
            den.Add(new byte[][] { ab, Ilk16(ab) });
        }
        if (eb != null && (eb.Length == 16 || eb.Length == 24 || eb.Length == 32)) den.Add(new byte[][] { eb, Ilk16(eb) });
        if (ek.Length == 16 || ek.Length == 24 || ek.Length == 32) { byte[] x = Encoding.UTF8.GetBytes(ek); den.Add(new byte[][] { x, Ilk16(x) }); }
        foreach (byte[][] d in den)
        {
            try
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Mode = CipherMode.CBC; aes.Padding = PaddingMode.PKCS7; aes.Key = d[0]; aes.IV = d[1];
                    using (ICryptoTransform t = aes.CreateDecryptor())
                    {
                        string s = Encoding.UTF8.GetString(t.TransformFinalBlock(sb, 0, sb.Length)).Trim();
                        if (Makul(s)) return s;
                    }
                }
            }
            catch (Exception) { }
        }
        return null;
    }

    public static string Coz(string metin, string[] anahtarlar)
    {
        if (metin == null) return null;
        string v = metin.Replace("-----BEGIN CERTIFICATE-----", "").Replace("-----END CERTIFICATE-----", "").Trim();
        for (int i = 0; i < 5; i++)
        {
            string j = Json(v); if (j != null) return j;
            v = Katman(v, anahtarlar); if (v == null) return null;
        }
        return Json(v);
    }
}
"@

Add-Type -TypeDefinition $kaynak -Language CSharp -IgnoreWarnings

$klasor = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$script:cikti = New-Object 'System.Collections.Generic.List[string]'
function Yaz([string]$m) { Write-Host $m; $script:cikti.Add($m) }
function Kaydet() { [IO.File]::WriteAllLines((Join-Path $klasor 'inat_link_sonuc.txt'), $script:cikti, (New-Object Text.UTF8Encoding($false))) }
function Kisalt([string]$s, [int]$n) { if ($null -eq $s) { return '' }; $t = $s -replace "[\r\n]+", ' '; if ($t.Length -gt $n) { return $t.Substring(0, $n) + '...' }; return $t }

function JsonNesnesi($deger) {
    if ($null -eq $deger) { return $null }
    $v = $deger
    if ($v -is [string]) {
        if ($v -eq 'null' -or $v.Trim() -eq '') { return $null }
        try { $v = $v | ConvertFrom-Json } catch { return $null }
    }
    if ($v -is [array]) { if ($v.Count -gt 0) { return $v[0] } else { return $null } }
    return $v
}

function BaslikAdi([string]$ad) {
    switch -Regex ($ad.ToLower().Replace('-', '').Replace('_', '')) {
        '^useragent$'      { return 'User-Agent' }
        '^xrequestedwith$' { return 'X-Requested-With' }
        '^(referer|referrer)$' { return 'Referer' }
        '^origin$'         { return 'Origin' }
        '^cookie$'         { return 'Cookie' }
        default            { return $ad }
    }
}

function Basliklar($ch) {
    $h = [ordered]@{}
    $n = JsonNesnesi $ch.chHeaders
    if ($n) { foreach ($p in $n.PSObject.Properties) { $d = [string]$p.Value; if ($d -and $d -ne 'null') { $h[(BaslikAdi $p.Name)] = $d } } }
    $r = JsonNesnesi $ch.chReg
    if ($r -and $r.playSH2 -and [string]$r.playSH2 -ne 'null') { $h['Cookie'] = [string]$r.playSH2 }
    return $h
}

function Diziler($h) { $a = @(); $d = @(); foreach ($k in $h.Keys) { $a += [string]$k; $d += [string]$h[$k] }; return ,@($a, $d) }

function Temizle([string]$a) { $t = $a.Trim().Replace('\/', '/').Replace('&', '&').Replace('&amp;', '&'); if ($t.StartsWith('//')) { $t = 'https:' + $t }; return $t }

function YayinDene([string]$adres, $h) {
    $hh = [ordered]@{}; foreach ($k in $h.Keys) { $hh[$k] = $h[$k] }
    if (-not $hh.Contains('Referer')) { try { $u = [Uri]$adres; $hh['Referer'] = $u.Scheme + '://' + $u.Host + '/' } catch {} }
    $x = Diziler $hh; $kod = 0; $tip = ''
    $govde = [InatT]::Get($adres, [string[]]$x[0], [string[]]$x[1], [NullString]::Value, [ref]$kod, [ref]$tip)
    Yaz ("      yayin GET -> " + $kod + " | " + $tip + " | " + (Kisalt $govde 90))
}

function KaynakCoz($ch) {
    $tip = ([string]$ch.chType) -replace '_mode$', ''
    $h = Basliklar $ch
    $reg = JsonNesnesi $ch.chReg
    $url = [string]$ch.chUrl
    if ($url.StartsWith('act')) { $url = 'https://vk.com/al_video.php?' + $url }
    Yaz ("    - " + $ch.chName + " | tip=" + $ch.chType + " | url=" + (Kisalt $url 160))
    Yaz ("      basliklar: " + (($h.Keys | ForEach-Object { $_ + '=' + (Kisalt $h[$_] 40) }) -join ' ; ') + " | chReg: " + (Kisalt ([string]($ch.chReg | ConvertTo-Json -Compress -Depth 4)) 300))
    $x = Diziler $h
    $adres = $null
    if ($tip -like 'tekli_regex_lb_sh*') {
        $anahtarlar = @(); foreach ($a in 'Regex1', 'Regex2', 'Regex2p') { if ($reg -and $reg.$a -and [string]$reg.$a -ne 'null') { $anahtarlar += [string]$reg.$a } }
        $kod = 0
        $ham = [InatT]::ImzaliGet($url, [string[]]$x[0], [string[]]$x[1], [ref]$kod)
        Yaz ("      imzali GET -> " + $kod + " | " + (Kisalt $ham 100))
        $json = [InatT]::Coz($ham, [string[]]($anahtarlar + [InatT]::VARS))
        if (-not $json) {
            Start-Sleep -Milliseconds 600
            $an = ''; $k2 = 0
            $ham2 = [InatT]::Istek($url, [ref]$an, [ref]$k2)
            Yaz ("      imzali POST -> " + $k2 + " | " + (Kisalt $ham2 100))
            $json = [InatT]::Coz($ham2, [string[]](@($an) + $anahtarlar + [InatT]::VARS))
        }
        Yaz ("      cozulen: " + (Kisalt $json 300))
        if ($json) { try { $o = JsonNesnesi $json; if ($o.chUrl) { $adres = Temizle ([string]$o.chUrl) } } catch {} }
    }
    elseif ($tip -like 'tekli_regex*' -or $tip -like 'nok5*') {
        $desen = if ($reg) { [string]$reg.Regex1 } else { '' }
        $post = [NullString]::Value; $sayfa = $url
        if ($tip -like 'nok5*' -and $url.Contains('al_video.php?')) { $post = $url.Substring($url.IndexOf('?') + 1); $sayfa = 'https://vk.com/al_video.php' }
        $kod = 0; $ct = ''
        $metin = [InatT]::Get($sayfa, [string[]]$x[0], [string[]]$x[1], $post, [ref]$kod, [ref]$ct)
        Yaz ("      sayfa -> " + $kod + " | " + $ct + " | " + (Kisalt $metin 100))
        if ($desen -and $desen -ne 'null') {
            try { $m = [regex]::Match($metin, $desen); if ($m.Success -and $m.Groups.Count -gt 1) { $adres = Temizle $m.Groups[1].Value } else { Yaz "      regex ESLESMEDI" } } catch { Yaz ("      regex hatasi: " + $_) }
        } else { $adres = $url }
    }
    else { $adres = Temizle $url }

    if ($adres) { Yaz ("      yayin adresi: " + (Kisalt $adres 200)); YayinDene $adres $h } else { Yaz "      YAYIN ADRESI COZULEMEDI" }
}

function IstekJson([string]$url, [string]$ad) {
    Start-Sleep -Milliseconds 800
    $an = ''; $kod = 0
    $ham = [InatT]::Istek($url, [ref]$an, [ref]$kod)
    $json = [InatT]::Coz($ham, [string[]]@($an, [InatT]::VARS))
    Yaz ("  istek " + $ad + " -> HTTP " + $kod + " | json=" + ($(if ($json) { $json.Length } else { 'YOK (' + (Kisalt $ham 80) + ')' })))
    return $json
}

Yaz "=== InatBox baglanti testi  $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ==="
try { Yaz ("Genel IP: " + (New-Object Net.WebClient).DownloadString('https://api.ipify.org')) } catch { Yaz 'Genel IP alinamadi' }

$dizin = IstekJson 'https://dizilabmedia.click/CDN/001/002/dizilab/v2/ct.php' 'kategori dizini'
if (-not $dizin) { Yaz 'Kategori dizini alinamadi; test bitti.'; Kaydet; Read-Host 'Bitti. Pencereyi kapatmak icin Enter'; exit }
[IO.File]::WriteAllText((Join-Path $klasor 'inat_link_kategoriler.json'), $dizin)
$katlar = @(try { $dizin | ConvertFrom-Json } catch { Yaz ('Dizin JSON okunamadi: ' + $_); @() })
Yaz ("Kategori sayisi: " + $katlar.Count + " | " + (($katlar | ForEach-Object { $_.catName }) -join ', '))

$istenen = @('Yerli Filmler', 'Netflix', 'Yabanci Diziler', 'Ulusal')
$no = 0
foreach ($ad in $istenen) {
    $kat = $katlar | Where-Object { ($_.catName -replace '[^a-zA-Z0-9]', '').ToLower() -eq ($ad -replace '[^a-zA-Z0-9]', '').ToLower() } | Select-Object -First 1
    if (-not $kat) { $kat = $katlar | Where-Object { $_.catName -like ('*' + $ad.Split(' ')[0] + '*') } | Select-Object -First 1 }
    Yaz ''
    Yaz ("##### " + $ad + " -> " + $(if ($kat) { $kat.catName + ' | ' + $kat.catUrl } else { 'BULUNAMADI' }))
    if (-not $kat) { continue }
    $no++
    $json = IstekJson ([string]$kat.catUrl) $ad
    if (-not $json) { continue }
    [IO.File]::WriteAllText((Join-Path $klasor ('inat_link_kat' + $no + '.json')), $json)
    $liste = @(try { $json | ConvertFrom-Json } catch { Yaz ('  JSON okunamadi: ' + $_); @() })
    Yaz ("  kayit: " + $liste.Count)
    $sayac = 0
    foreach ($k in $liste) {
        if ($sayac -ge 2) { break }
        $tur = ([string]$(if ($k.diziType) { $k.diziType } else { $k.chType })) -replace '_mode$', ''
        if ($tur -in @('link', 'web', 'destek')) { continue }
        $sayac++
        if ($k.diziType) {
            Yaz ("  * " + $k.diziName + " | diziType=" + $k.diziType + " | diziUrl=" + $k.diziUrl)
            $alt = IstekJson ([string]$k.diziUrl) 'icerik'
            if (-not $alt) { continue }
            $altListe = @(try { $alt | ConvertFrom-Json } catch { Yaz ('    JSON okunamadi: ' + $_); @() })
            if ($tur -eq 'dizi') {
                Yaz ("    sezon: " + $altListe.Count + " | ilk: " + $altListe[0].diziName)
                $bol = IstekJson ([string]$altListe[0].diziUrl) 'sezon 1'
                if (-not $bol) { continue }
                $bListe = @(try { $bol | ConvertFrom-Json } catch { Yaz ('    JSON okunamadi: ' + $_); @() })
                Yaz ("    bolum: " + $bListe.Count)
                if ($bListe.Count -gt 0) { KaynakCoz $bListe[0] }
            } else {
                Yaz ("    kaynak: " + $altListe.Count)
                foreach ($ch in ($altListe | Select-Object -First 3)) { Start-Sleep -Milliseconds 500; KaynakCoz $ch }
            }
        } else {
            Yaz ("  * " + $k.chName + " (kanal/film kaydi)")
            KaynakCoz $k
        }
    }
    Kaydet
}

Yaz ''
Yaz '=== BITTI ==='
Kaydet
Read-Host 'Bitti. Sonuc inat_link_sonuc.txt dosyasina yazildi. Pencereyi kapatmak icin Enter'
